<?php
SESSION_START();
$mid = $_SESSION['uid'];
include('conn.php');
?>
<html>
<head>
<title>REQUEST</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Augment Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
	<!-- Custom CSS -->
<link href="css/stylerequest.css" rel='stylesheet' type='text/css' />
	<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
	<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'>
	<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
	<!-- /js -->
<script src="js/jquery-1.10.2.min.js"></script>
<!--<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />--> 
<link href="css/bootstrap2.css" rel="stylesheet" type="text/css" media="all" />
<!-- //js-->
</head> 
<!--Start of Tawk.to Script-->
<!--<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/59c8b91bc28eca75e4622099/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->	
	
<body>
<h1 class="inner-tittle two" style="align-content:center;">Matching Results</h1>
	<div class="graph">
			<!--<div class="tables">-->
				<!--	<table class="table"> 
	<thead> 
					<tr> 

						<th>name</th>
						<th>departure_date</th>
						<th>return_date</th>
						<th>source_city</th>
						<th>destination_city</th>
						<th>per_person_cost</th>
						<th>book car</th>
						<th>view details</th>
						<!--<th>bookride</th>
					</tr> 
					</thead> -->
					<?php
				$fd = $_POST['fd'];
				$td= $_POST['tde'];
				$city = $_POST['to'];

				//echo $fd;
				$sql = "SELECT * FROM  `host` WHERE from_date <= '$fd' and to_date >= '$td'  and city_name='$city' LIMIT 0 , 30";//ORDER BY  `host`.`host_id` DESC";
				//echo $sql;
			$q=mysql_query($sql);
$no=0;
while($res=mysql_fetch_array($q))
{
$no=$no+1; ?>	
				<table>
					<tr>
						<td width="5000" style="padding-top:0px;"><img src="<?php echo 'data:image;base64,'.$res[12].' '; ?>" height="150" width="250" />
						
						<td width="800" style="padding-top:0px; padding-left:10px; margin-left:5px;">Address :<br> <?php echo $res[4]; ?> <br>
						Number Of room :<br> <?php echo $res[7]; ?> <br>
						Price :<br> <?php echo $res[8]; ?> <br>
						House Type :<br> <?php echo $res[9]; ?><br>
						From Date:<br>
						<?php echo $res[2]; ?><br>
						To Date:<br>
						<?php echo $res[3]; ?>
						</td>
					</tr>
					<div style="margin-top: 100px;">
	<a href="cs_book.php"><button type="button" name="book"  class=" btn-lg btn-primary" >Book-Room</button></a>
	</div>
	<div style="margin-top: 100px;">
	<a href="cs_view.php"><button type="button" name="book"  class=" btn-lg btn-primary" >View preference</button></a>
	</div>
		<?php
		echo"<hr>";
	
	}
?>

	

	
	
	
	
	
	
	
				</table>
				<hr>
			<?php
				}
				?>
					</div>
                </div>
             	</div>
            </div>
        </div>
		 <!-- //Horizontal Tab -->


    </div>
    
					

		
							
</body>
</html>