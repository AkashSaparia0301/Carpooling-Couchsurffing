
<?php
session_start();
if(isset($_POST['signup']))
	{
		$first_name=$_POST['first_name'];
		$last_name=$_POST['last_name'];
		$username=$_POST['username'];
		$email=$_POST['email'];
		$password=$_POST['password'];
		$contact_number=$_POST['contact_number'];
		$gender=$_POST['gender'];

		
	
		
		$sql="INSERT INTO `member` (`member_id`,`first_name`,`last_name`,`username`,`email`,`password`,`contact_number`,`gender`) VALUES (NULL,'$first_name','$last_name','$username','$email','$password','$contact_number','$gender')";
		
		$result=mysql_query($sql,$link);
		
		echo"<h4> You are Registered...</h4>";
	}
	
	if(isset($_POST['login']))
	{
		
		$username=$_POST['username'];
		$password=$_POST['password'];
	
		$login="select * from `member` where username='$username' and password='$password' ";
		$res=mysql_query($login);
		$no=mysql_num_rows($res);
		/*if(isset($res))
		{

			$_SESSION['username']=$_POST['username'];
			$_SESSION['password']=$_POST['password'];
		}*/
		
		if(!$res)
		{
			
			echo 'could not run empty: ' . mysql_error();
			exit;
		}
		//echo $no;
		if($no>0)
		{
			while($row=mysql_fetch_array($res))
			{
			$_SESSION['uid']=$row['member_id'];
			echo $_SESSION['uid'];
			}
			$_SESSION["username"]=$username;
			$_SESSION["password"]=$password;
			header("location:index.php");
		}
		else
		{
			
			header("location:login.php?msg=err");
		}
	}
?>
