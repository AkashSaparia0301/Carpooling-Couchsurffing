<?php
session_start();
$mid = $_SESSION['uid'];
include('conn.php');

	
?>
<?php
	
	if(isset($_GET['submitinfo']))
	{
	//$cp_preference_id=$_POST['cp_preference_id'];
		
		
		//$verified=implode(',',$_GET['ch']);
		$wheelchair=$_GET['wheelchair'];
		$ac_nonac=$_GET['ac_nonac'];
		$gender=$_GET['gender'];
		$pet=$_GET['pet'];
		$kid=$_GET['kid'];
		$music=$_GET['music'];
		$smoking=$_GET['smoking'];
		$drinking=$_GET['drinking'];
		$food=$_GET['food'];
		$wifi=$_GET['wifi'];
		$vehicle=$_GET['vehicle'];
		$language=$_GET['language'];
	$language_txt=$_GET['language_txt'];
	
	
		//echo $language;
		
		//$ac=$_POST['ac'];
		//$nonac=$_POST['nonac'];
		//$wheelchair=$_POST['wheelchair'];
		//$select_query1="select host_id from host";
		//$res=mysql_query($select_query1);
		//while($row=mysql_fetch_array($res))
			//{
			//$_SESSION['hid']=$row['host_id'];
			//echo $_SESSION['hid'];
		    //}
		//echo $select_query1 ;


		//$query3="UPDATE `host` set type_of_house='$typeofhouse',type_of_room='$typeofroom',furniture'$furniture' where host_id='$hid' "
		
		//$query2=("INSERT INTO `host`( `type_of_house`, `type_of_room`, `furniture`) VALUES('$typeofhouse','$typeofroom','$furniture')");
		
		//$result2=mysql_query($query2,$link);
		/*$query1=mysql_query("INSERT INTO `cs_member_preference`( `member_id`, `verified`, `gender`, `pet`, `kid`, `music`, `smoking`, `drinking`, `food`, `wifi`, `vehicle`, `language`) VALUES('$mid','".$verified."','$gender','$pet','$kid','$music','$smoking','$drinking','$food','$wifi','$vehicle','$language')",$link);*/
	
		if($language!="Others")
		{
	    

	//$result1=//mysql_query("INSERT INTO `cs_member_preference`( `member_id`, `wheelchair`,`ac_nonac`, `gender`, `pet`, `kid`, `music`, `smoking`, `drinking`, `food`, `wifi`, `vehicle`, `language`) VALUES('$mid','$wheelchair','$ac_nonac','$gender','$pet','$kid','$music','$smoking','$drinking','$food','$wifi','$vehicle','$language_txt')",$link);
		$result1=mysql_query("INSERT INTO `cs_member_preference`( `member_id`, `wheelchair`,`ac_nonac`, `gender`, `pet`, `kid`, `music`, `smoking`, `drinking`, `food`, `wifi`, `vehicle`, `language`) VALUES('$mid','$wheelchair','$ac_nonac','$gender','$pet','$kid','$music','$smoking','$drinking','$food','$wifi','$vehicle','$language')",$link);
	}
	else
	{  
		$language_txt=$_GET['language_txt'];
		

//$result1=mysql_query("INSERT INTO `cs_member_preference`( `member_id`, `wheelchair`,`ac_nonac`, `gender`, `pet`, `kid`, `music`, `smoking`, `drinking`, `food`, `wifi`, `vehicle`, `language`) VALUES('$mid','$wheelchair','$ac_nonac','$gender','$pet','$kid','$music','$smoking','$drinking','$food','$wifi','$vehicle','$language')",$link);
		$result1=mysql_query("INSERT INTO `cs_member_preference`( `member_id`, `wheelchair`,`ac_nonac`, `gender`, `pet`, `kid`, `music`, `smoking`, `drinking`, `food`, `wifi`, `vehicle`, `language`) VALUES('$mid','$wheelchair','$ac_nonac','$gender','$pet','$kid','$music','$smoking','$drinking','$food','$wifi','$vehicle','$language_txt')",$link);
	}		
	
		

		if($result1)
		{
			

          
			header("location:become_host.php");
		}
		

		/*$result2=mysql_query($query2,$link);
		if($result2)
		{
			echo "successfully updated";
		}
		else
		{
				echo "not updated <br/>";
		}*/
	}
?>