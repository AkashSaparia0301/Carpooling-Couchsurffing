<?php
include('conn.php');
session_start();
$mid = $_SESSION['uid'];
if(isset($_POST['offerride']))
	{
		
		$heading=$_POST['heading'];
		$leaving=$_POST['leaving'];
		$departuredate=$_POST['departuredate'];
		$departuretime=$_POST['departuretime'];
		$middleseat=$_POST['middleseat'];
				$noofseat=$_SESSION['noofseat']=$_POST['noofseat'];
  		$_SESSION['noofseat'];
		echo $noofseat;
		
		$per_person_cost=$_POST['per_person_cost'];
		$type_of_journey=$_POST['type_of_journey'];
		$returndate=$_POST['returndate'];
		$returntime=$_POST['returntime'];
		$drivinglicencenumber=$_POST['drivinglicencenumber'];

		
		$file=$_FILES["file"]["name"];
		move_uploaded_file($_FILES['file']['tmp_name'],"images/".$_FILES['file']['name']);
		
		
		$sql="INSERT INTO `offer_ride`(`member_id`,  `heading`, `leaving`, `going_date`, `going_time`, `comfortable`,`noofseat`, `per_person_cost`, `type_of_journey`, `return_date`, `return_time`, `driving_licence_number`,`file3`) VALUES('$mid','$heading','$leaving','$departuredate','$departuretime','$middleseat',$noofseat,$per_person_cost,'$type_of_journey','$returndate','$returntime',$drivinglicencenumber,'$file')";
		
		$result=mysql_query($sql,$link);
		if($result)
		{
			

          
			header("location:offer_ride.php");
		}
		}
	
	?>
	<?php
	if(isset($_POST['submitinfo']))
	{
			$name=$_POST['name'];
		$model=$_POST['model'];
		$make_year=$_POST['make_year'];
		$number_plate=$_POST['number_plate'];
		$type_of_car=$_POST['type_of_car'];
		$color=$_POST['color'];





		
		$ac_nonac=$_POST['ac_nonac'];
		
		$gender=$_POST['gender'];
		$pet=$_POST['pet'];
		$kid=$_POST['kid'];
		$music=$_POST['music'];
		$smoking=$_POST['smoking'];
		$firstaid=$_POST['firstaid'];
		$window=$_POST['window'];
		$luggage=$_POST['luggage'];
		$wifi=$_POST['wifi'];
     
		$query2="INSERT INTO `car`( `member_id`, `name`, `model`, `make_year`, `number_plate`, `type_of_car`, `color`) VALUES('$mid','$name','$model','$make_year','$number_plate','$type_of_car','$color')";

		mysql_query($query2,$link);

		$query1="INSERT INTO `cp_member_preference`( `member_id`, `ac_nonac`, `gender`, `pet`, `kid`, `music`, `smoking`, `firstaid`, `window`, `luggage`, `wifi`) VALUES('$mid','$ac_nonac','$gender','$pet','$kid','$music','$smoking','$firstaid','$window','$luggage','$wifi')";
		mysql_query($query1,$link);

		if($query2)
		{
			

          
			header("location:offer_ride.php");
		}
}
	
		
	
	?>