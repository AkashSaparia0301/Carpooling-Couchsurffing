<?php
session_start();
if(isset($_SESSION['username']))
{
	include('conn.php');
	
	
?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->


<!DOCTYPE html>

<html>
<head>
<title>KNOCK</title>


<!-- custom-theme -->

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Simple Login and Signup Form web template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>

<!-- //custom-theme -->


<link href="css/style10.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/mislider.css" rel="stylesheet" type="text/css" />
<link href="css/test.css" rel="stylesheet" type="text/css" />
<link href="css/mislider-custom.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /> 

<!-- Bootstrap-Core-CSS -->

<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /> <!-- Style-CSS --> 
<link rel="stylesheet" href="css/font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->

<!-- js -->
<script src="js/jquery-1.9.1.min.js"></script>
<!--// js -->

<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />
 <link href="//fonts.googleapis.com/css?family=Questrial" rel="stylesheet">
</head>


<body class="bg agileinfo">
<div class="container">
			<div class="banner_top">
				<div class="logo wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
					<h1><a href="index.html"><span>K</span>nock</a></h1>
				</div>
				<div class="banner_top_right wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
					<nav class="navbar navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				
				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav cl-effect-14">
					<?php
							include('process1.php');
					?>
						<!--<li><a href="index.php">Home</a></li>
						<li><a href="about.php">About Us</a></li>
						<li><a href="carpool.php">Carpooling</a></li>
						<li><a href="couchsurfing.php" class="active">Couch_Surfing</a></li>
						<li><a href="services.html">Services</a></li>
						<li><a href="gallery.php">Gallery</a></li>
						<!--<li><a href="codes.html">Codes</a></li>
						<li><a href="contact.php">Contact Us</a></li>
						<li><a href="login.php">login</a></li>-->
					</ul>
				</div><!-- /.navbar-collapse -->	
				
			</nav>
				</div>
				<div class="clearfix"> </div>
			</div>
			<!-- banner -->
		
		</div>
	</div>
<!-- //banner -->


   <!--<h1 class="agile_head text-center"> Simple Login and Signup Form</h1>-->

   <div class="w3layouts_main wrap">
    <!--Horizontal Tab-->
    
        <div id="parentHorizontalTab_agile">
            <ul class="resp-tabs-list hor_1">
                <li>Find Host</li>
                <!--<li>Apply Filters</li>-->
            </ul>
            <div class="resp-tabs-container hor_1">
               <div class="w3_agile_login">
			   <div class="agile_its_registration">
                    <form action="cs_request.php" method="post" class="agile_form">
					  <p>Going To:</p>
					<!-- <input required="required" name="goingto"onfocus="if (this.value=='Where are you Going ?') this.value = ''" type="text"  value="Where are you Going ?" />-->
					  <?php
					$sql="select city_name from city";
					$result=mysql_query($sql);
					?>
					<select required="required" onFocus="if(this.value'city') this.value=''" type="text" value="city" name="to">

					<?php
					while($row=mysql_fetch_array($result))
					{

						echo "<option value='".$row['city_name']."'>".$row['city_name']."</option>";
					}
					?>
					</select>
					
					  
					  <p>Number of Travelers:</p>
					  <input required="required"onfocus="if (this.value=='Number of Travelers') this.value = ''" type="text"  value="Number of Travelers"  name="n"  />
					 <p>From:</p>
					 <!--<input  name="ffdate" onfocus="if (this.value=='dd-mm-yyyy') this.value = ''" type="date" value="dd-mm-yyyy">-->
					 <input type="date" onClick="myFunction4()" id="myDate" name="fd" min="2017-09-16">
					 <script>
						function myFunction4()
						{
							var x= document.getElementById("myDate").min="2017-09-16";
							document.getElementById("demo").innerHTML =" THE value of min attribute was changed from '1980-01-01' to '1999-01-01'.";
						}
					 </script>
					 <p>To:</p>
					 <!--<input   name="ttdate" onfocus="if (this.value=='dd-mm-yyyy') this.value = ''" type="date" value="dd-mm-yyyy">-->
					 <input type="date" onClick="myFunction4()" id="myDate" name="tde" min="2017-09-16">
					 <script>
						function myFunction4()
						{
							var x= document.getElementById("myDate").min="2017-09-16";
							document.getElementById("demo").innerHTML =" THE value of min attribute was changed from '1980-01-01' to '1999-01-01'.";
						}
					 </script>
					 
					  <input type="submit" name="submit" value="findhost" class="agileinfo" />
					</form>
					</div>
					 
                    
                </div>
                <div class="agile_its_registration">
                   <!-- <form action="#" method="post" class="agile_form">
					<input type="checkbox" name="verified"  value="verified"> Verfied<br>
					  <input type="checkbox" name="ac" value="ac"> AC<br>
					  <input type="checkbox" name="non_ac" value="non_ac"> NON-AC<br>
					  <input type="checkbox" name="wheelchair"  value="wheelchair">Wheelchair Accessible <br>
					  
					  <p>Accomodation:</p><br>
					  
					  <input type="checkbox" name="private"  value="private"> Private Room<br>
					  <input type="checkbox" name="public" value="public"> Public Room<br>
					  <input type="checkbox" name="shared" value="shared"> Shared Room<br>
					  <input type="checkbox" name="shared_sleeping_surface" value="shared sleeping surface"> Shared Sleeping Surface<br>
					  
					 
					  
					
					  <p>Gender Selection:</p>
					  <select required="required" name="gender"onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="male">Male</option>
					  <option value="female">Female</option>
					  <option value="other">Other</option>
					 
					  </select>
					 
					  
					  
					  
					  <p>Pet Allowed:</p>
					  <select required="required" name="pet"onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					  
					  
					  <p>Kids Allowed:</p>
					  <select required="required" name="kid"onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">YES</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					  <p>Music Allowed:</p>
					  <select required="required" name="music"onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					  <p>Smoking Allowed:</p>
					  <select required="required" name="smoking"onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no prference">No Preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					  <p>Drinking Allowed:</p>
					  <select required="required" name="drinking"onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					   <p>Food Offered:</p>
					  <select required="required" name="food"onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					   
					   <p>WI-FI Offered:</p>
					  <select required="required" name="wifi"onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					   
					   <p>Vehicle Offered:</p>
					  <select required="required" name="vehicle"onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					  <p>Language Spoken*</p>
					  <input required="required"  name="language" onfocus="if (this.value=='Name') this.value = ''" type="text"  value="Language Spoken" />
					  
					 
					   <input type="submit" name="addfilters" value="Add Filtes"/>
					   <input type="reset"  name="reset"value="Reset" />
					</form> -->
				</div>
            </div>
        </div>
		 <!-- //Horizontal Tab -->
    </div>
	<div class="agileits_w3layouts_copyright text-center">
			<!--<p><a href="//w3layouts.com/">W3layouts</a></p>-->
	</div>
<!--tabs-->
<script src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	//Horizontal Tab
	$('#parentHorizontalTab_agile').easyResponsiveTabs({
		type: 'default', //Types: default, vertical, accordion
		width: 'auto', //auto or any width like 600px
		fit: true, // 100% fit in a container
		tabidentify: 'hor_1', // The tab groups identifier
		activate: function(event) { // Callback function if tab is switched
			var $tab = $(this);
			var $info = $('#nested-tabInfo');
			var $name = $('span', $info);
			$name.text($tab.text());
			$info.show();
		}
	});
});
</script>
<script type="text/javascript">
		window.onload = function () {
			document.getElementById("password1").onchange = validatePassword;
			document.getElementById("password2").onchange = validatePassword;
		}
		function validatePassword(){
			var pass2=document.getElementById("password2").value;
			var pass1=document.getElementById("password1").value;
			if(pass1!=pass2)
				document.getElementById("password2").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("password2").setCustomValidity('');	 
				//empty string means no validation error
		}

</script>
<!--//tabs-->
</body>
</html>

<?php

}
else
{
header("location:index.php");
}
?>