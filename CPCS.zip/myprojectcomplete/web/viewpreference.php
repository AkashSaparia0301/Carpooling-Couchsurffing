<?php
SESSION_START();
$mid = $_SESSION['uid'];
include('conn.php');
	
$l=$_SESSION['leavingfrom'];
$g=$_SESSION['goingto'];
$t=$_SESSION['traveldate'];

//echo $l;
//echo $g;
//echo $t;

/*$query1="select * from new_offer_ride";
$result1=mysql_query($query1,$conn);
while($row=mysql_fetch_array($result1))
{
	$p=$row[8];
	$d=$row[9];
}
*/

?>

<?php
	$ressult56="select offer_id from cs_member_preference";
    $query="select offer_id from offer_ride";
    $result5=mysql_query($query,$link);

    while($row=mysql_fetch_array($result5))
    {
    	 $row['offer_id'];
    }
    

    $query1="select member_id from member";

    $result2=mysql_query($query1,$link);
    while($row=mysql_fetch_array($result2))
    {
    	  $row['member_id'];
    }
    
    //$result15=mysql_query("SELECT offer_ride.member_id,member.username,`heading`,`leaving` ,`per_person_cost`,`going_date`,`going_time`from offer_ride LEFT JOIN member ON offer_ride.member_id = member.member_id where offer_ride.heading = '$g' and offer_ride.leaving='$l' and offer_ride.going_date='$t'");
     $result17=mysql_query("SELECT offer_ride.member_id,member.username from offer_ride LEFT JOIN member ON offer_ride.member_id = member.member_id where offer_ride.heading = '$g' and offer_ride.leaving='$l' and offer_ride.going_date='$t'");
     //$result18=mysql_query("SELECT offer_ride.member_id,member.username from offer_ride LEFT JOIN member ON offer_ride.member_id = member.member_id where offer_ride.heading = '$g' and offer_ride.leaving='$l' and offer_ride.going_date='$t'");
     $result16=mysql_query("select * from cp_member_preference LEFT JOIN offer_ride ON offer_ride.member_id=cp_member_preference.member_id where offer_ride.heading = '$g' and offer_ride.leaving='$l' and offer_ride.going_date='$t'");
    //$result16=mysql_query("select * from cp_member_preference where cp_member_preference.member_id=offer_ride.member_id");

	//$result1=mysql_query("select `username` from `member` where offer_id.member_id=member.member_id");
	//$result1=mysql_query("select `username` from `member` where offer_id.member_id=member.member_id");

	//$result0=mysql_query("select member.username from member INNER JOIN offer_ride ON offer_ride.member_id=member.member_id ");
	//$result1=mysql_query("select member.username from mcsember INNER JOIN offer_ride where heading='$g' && leaving='$l' && going_date='$t' && offer_ride.member_id=member.member_id  
		//UNION
		//$result1=mysql_query("select `offer_ride.member_id`,`member.username`,`heading`,`leaving` from offer_ride LEFT JOIN member ON `offer_ride.member_id` = `member.member_id` where 'offer_ride.heading' = '$g' and 'offer_ride.leaving'='$l' and 'offer_ride.going_date'='$t'  ");
		//mysql_query("select `heading`, `leaving`, `going_date`, `going_time`,`per_person_cost` from `offer_ride` where heading='$g' && leaving='$l' && going_date='$t'");

if($result16)
{
	//echo "sucess";
}
else
{
	mysql_error();
}

	//$result=mysql_query("select `heading`, `leaving`, `going_date`, `going_time`,`per_person_cost` from `offer_ride` where heading='$g' && leaving='$l' && going_date='$t'");
	//$result=mysql_query("select  ``, `return_date`, `source_city`, `destination_city`, `per_person_cost` from `offer_ride` where source_city='$l' && destination_city='$g' && departure_date='$c'");
?>
<html>
<head>
<title>View Preference</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Augment Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
	<!-- Custom CSS -->
<link href="css/stylerequest.css" rel='stylesheet' type='text/css' />
	<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
	<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'>
	<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
	<!-- /js -->
<script src="js/jquery-1.10.2.min.js"></script>
<!--<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />--> 
<link href="css/bootstrap2.css" rel="stylesheet" type="text/css" media="all" />
<!-- //js-->
</head> 
<!--Start of Tawk.to Script-->
<!--<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/59c8b91bc28eca75e4622099/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->	
	
<body style="background-color:white";>
<h1 class="inner-tittle two" style="align-content:center;">Member Preference</h1>
	<div class="graph">
			<!--<div class="tables">-->
				<!--	<table class="table"> 
	<thead> 
					<tr> 

						<th>name</th>
						<th>departure_date</th>
						<th>return_date</th>
						<th>source_city</th>
						<th>destination_city</th>
						<th>per_person_cost</th>
						<th>book car</th>
						<th>view details</th>
						<!--<th>bookride</th>
					</tr> 
					</thead> -->	
									
	<?php
		while($row=mysql_fetch_array($result17))
	{
	
		echo"Preference of user:";
		echo$row['username'];
		echo"are as follows";
		echo"<br>";
	}
	
	
while($row=mysql_fetch_array($result16))
	{


		echo"<hr>";
		echo"Ac/NonAc             :";
		echo $row['ac_nonac'];
		echo"<br>";
		echo"Gender               :";
		echo $row['gender'];
		echo"<br>";
		echo"pet allowed          :";
		echo $row['pet'];
		echo"<br>";
		echo"Kid allowed          :";
		echo $row['kid'];
		echo"<br>";
		echo"Music Allowed        :";
		echo $row['music'];
		echo"<br>";
		echo"Smoking Allowed      :";
		echo $row['smoking'];
		echo"<br>";
		echo"First-Aid allowed    :";
		echo $row['firstaid'];
		echo"<br>";
		echo"Window Seat offered  :";
		echo $row['window'];
		echo"<br>";
		echo"Luggage specification:";
		echo $row['luggage'];
		echo"<br>";
		echo"Wi-Fi Offered        :";
		echo $row['wifi'];
		echo"<br>";
		echo"<hr>";

	}
	?>

	   
	
	

		
		
<hr>	
					
					
			</div>
					
	</div>
	

	
	
	
	
	
	
	
	
</body>
</html>