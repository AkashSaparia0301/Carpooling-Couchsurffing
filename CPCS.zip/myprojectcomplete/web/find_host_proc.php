<?php
//SESSION_START();
	/*if(isset($_GET['apply']))
	{
		
		$verified=$_GET['verified'];
		$ac=$_GET['ac'];
		$non_ac=$_GET['non_ac'];
		$first_aid=$_GET['first_aid'];
		$gender=$_GET['gender'];
		$smoking=$_GET['smoking'];
		$pet=$_GET['pet'];
		$kid=$_GET['kid'];
		$music=$_GET['music'];
		$luggage=$_GET['luggage'];
		$window=$_GET['window'];
		
		
		
	}*/
	
	if(isset($_GET['FindRide']))
	{
		
		$_SESSION['goingto']=$_GET['goingto'];
		//echo $_SESSION['leavingfrom'];
		echo $_SESSION['whereareyoucomingfrom']=$_GET['whereareyoucomingfrom'];
		echo $_SESSION['ffdate']=$_GET['ffdate'];
		echo $_SESSION['ttdate']=$_GET['ttdate'];
		
		header("location:request.php");
	
	}
?>
