<?php
SESSION_START();
$mid = $_SESSION['uid'];
include('conn.php');
	
	?>

<?php
	
    			$fd = $_POST['fd'];
				$td= $_POST['tde'];
				$city = $_POST['to'];

    $query1="select member_id from member";

    $result2=mysql_query($query1,$link);
    while($row=mysql_fetch_array($result2))
    {
    	  $row['member_id'];
    }
    
    $result15=mysql_query("SELECT * FROM  `host` WHERE from_date <= '$fd' and to_date >= '$td'  and city_name='$city' LIMIT 0 , 30");
    
if($result15)
{
	echo "sucess";
}
else
{
	mysql_error();
}

	//$result=mysql_query("select `heading`, `leaving`, `going_date`, `going_time`,`per_person_cost` from `offer_ride` where heading='$g' && leaving='$l' && going_date='$t'");
	//$result=mysql_query("select  ``, `return_date`, `source_city`, `destination_city`, `per_person_cost` from `offer_ride` where source_city='$l' && destination_city='$g' && departure_date='$c'");
?>
<html>
<head>
<title>REQUEST</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Augment Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
	<!-- Custom CSS -->
<link href="css/stylerequest.css" rel='stylesheet' type='text/css' />
	<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
	<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'>
	<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
	<!-- /js -->
<script src="js/jquery-1.10.2.min.js"></script>
<!--<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />--> 
<link href="css/bootstrap2.css" rel="stylesheet" type="text/css" media="all" />
<!-- //js-->
</head> 
<!--Start of Tawk.to Script-->
<!--<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/59c8b91bc28eca75e4622099/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->	
	
<body>
<h1 class="inner-tittle two" style="align-content:center;">Matching Results</h1>
	<div class="graph">
			<!--<div class="tables">-->
				<!--	<table class="table"> 
	<thead> 
					<tr> 

						<th>name</th>
						<th>departure_date</th>
						<th>return_date</th>
						<th>source_city</th>
						<th>destination_city</th>
						<th>per_person_cost</th>
						<th>book car</th>
						<th>view details</th>
						<!--<th>bookride</th>
					</tr> 
					</thead> -->					
	<?php
//while($row=mysql_fetch_array($result16))
	//{
		//echo"luggage";
		//echo $row['luggage'];
		//echo"<br>";
	//}<?php
				
    
	

	   
	
	while($row=mysql_fetch_array($result15))
	{

		echo"<hr>";
		echo"<b>";
		echo "house Image:";
		echo"<br>";
		
		?>
	<img src="images/<?php echo $row['file']; ?>"
	style="height:200px;width:200px;">
		
		<?php
		echo "<br>";
		echo"<br>";
		echo"<b>";
		echo"From Date:";
		echo $row['from_date'];
		echo"<br>";
		echo "To Date:"; 
		echo $row['to_date'];
		echo"<br>";
		echo "Address:";
		echo $row['address'];
		echo"<br>";
	
		echo"<br>";
		echo"<br>";

		?>
		<form>
		<div style="margin-left:450px; margin-top:-152px;">
		 <a href="csbook.php"><button type="button" name="book"  class=" btn-lg btn-primary" >book</button></a>
		</div>
		<br>
		<br>
		<br>

		
		
		<?php
		echo"<hr>";
	
	}
?>
<br>
<br>
<a href="viewpreference.php">
		<div style="margin-left:420px; margin-top:39px;">
		<button type="button" class=" btn-lg btn-primary" > view-prefrence
		</button>
</a>
		</div>
	

	
	
	
	
	
	
	
	
</body>
</html>