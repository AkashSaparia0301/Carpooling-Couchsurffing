
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->


<!DOCTYPE html>


<html lang="en">
<head>
<title>KNOCK</title>


<!-- Meta tag Keywords -->

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Auto Car Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>

<!--// Meta tag Keywords -->


<!-- css files -->

<link href="css/bootstrap1.css" rel="stylesheet" type="text/css" media="all" /> <!-- Bootstrap-Core-CSS -->
<link href="css/style7.css" rel="stylesheet" type="text/css" media="all" /> <!-- Style-CSS --> 
<link rel="stylesheet" href="css/font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->

<!-- //css files -->


<!-- online-fonts -->

<link href="//fonts.googleapis.com/css?family=Jockey+One&amp;subset=latin-ext" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Niconne&amp;subset=latin-ext" rel="stylesheet">


<!-- //online-fonts -->

<style> 
/*input[type=text] 
{
  	width: 130px;
    box-sizing: border-box;
	border:  solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    
	background-color: transparent;
	
    background-image: url();
	 
    background-position: 10px 10px; 
    background-repeat: no-repeat;
     padding: 12px 20px 12px 40px;
     -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}

input[type=text]:focus {
    width: 100%;
}*/
</style>


</head>
	
<body>
<!-- banner -->
	<div class="banner-4 wthree">
		<div class="container">
			<div class="banner_top">
			<!--<form>	 
					<input type="text" name="search" placeholder="Search.."   >
			</form>-->
				<div class="logo wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
					<h1><a href="index.html"><span>K</span>nock</a></h1>
				</div>
				<div class="banner_top_right wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
					<nav class="navbar navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->

				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav cl-effect-14">
					<?php
					include('process.php');
					?>
						<!--<li><a href="index.php">Home</a></li>
						<li><a href="about.php">About Us</a></li>
						<?php 
								//session_start();
								//if(isset($_SESSION['username']) && isset($_SESSION['password']))
								{
									?>
									 	<li><a href="carpool.php">Carpooling</a></li>
										<li><a href="couchsurfing.php">Couch_Surfing</a></li>
										<?php
								}
						?>
						
						<li><a href="carpool.php">Carpooling</a></li>
						<li><a href="couchsurfing.php">Couch_Surfing</a></li>
						<li><a href="services.html">Services</a></li>
						<li><a href="gallery.php">Gallery</a></li>
						<!--<li><a href="codes.html">Codes</a></li>
						<li><a href="contact.php" class="active">Contact Us</a></li>
						<li><a href="login.php">login</a></li>-->
					</ul>
				</div><!-- /.navbar-collapse -->	
				
			</nav>
				</div>
				<div class="clearfix"> </div>
			</div>
			<!-- banner -->
		
		</div>
	</div>
<!-- //banner -->

<!-- Main -->
<!-- Contact -->
	<div class="con-agile">
		<div class="container">
			<h2>Contact Us</h2>
			<div class="contact-form">
				<h4>Get in Touch</h4>
				<form action="contact_proc.php" method="GET">
					<div class="col-md-6 form-left">
						<input type="text" placeholder="Name" name="name" required="">
					</div>
					<div class="col-md-6 form-right">
						<input class="email" type="email" name="email" placeholder="Email" required="">
					</div>
					<div class="clearfix"> </div>
						<input class="" type="text" placeholder="Phone" name="phone" required="">
						<textarea class="" placeholder="Message" name="message" required=""></textarea>
						<input type="submit" name="submit" value="SUBMIT" >
				</form>
			</div>
		</div>
		<div class="contact-map">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d212126.07899261903!2d150.68928304602147!3d-33.82598834810063!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b129838f39a743f%3A0x3017d681632a850!2sSydney+NSW%2C+Australia!5e0!3m2!1sen!2sin!4v1463468876401"  allowfullscreen></iframe>
		</div>
	</div>
<!-- //Contact -->
<!-- //Main -->

<!-- Footer -->
<?php
include('footer.php');
?>

<!-- Footer -->	

<!-- js-scripts -->						
		<!-- js -->
			<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
			<script type="text/javascript" src="js/bootstrap.js"></script> <!-- Necessary-JavaScript-File-For-Bootstrap --> 
		<!-- //js -->
		<script src="js/jzBox.js"></script>
<!-- //js-scripts -->
</body>
</html>