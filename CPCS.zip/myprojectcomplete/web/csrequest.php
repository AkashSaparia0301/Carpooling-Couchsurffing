<?php
	include('conn.php');
	
	if(isset($_POST['submit']))
	{
?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->


<!DOCTYPE html>

<html>
<head>
<title>KNOCK</title>


<!-- custom-theme -->

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>

<!-- //custom-theme -->


<link href="css/style10.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/mislider.css" rel="stylesheet" type="text/css" />
<link href="css/test.css" rel="stylesheet" type="text/css" />
<link href="css/mislider-custom.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /> 

<!-- Bootstrap-Core-CSS -->

<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /> <!-- Style-CSS --> 
<link rel="stylesheet" href="css/font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->

<!-- js -->
<script src="js/jquery-1.9.1.min.js"></script>
<!--// js -->

<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />
 <link href="//fonts.googleapis.com/css?family=Questrial" rel="stylesheet">
</head>


<body class="bg agileinfo">
<div class="container">
			<div class="banner_top">
				<div class="logo wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
					<h1><a href="index.html"><span>K</span>nock</a></h1>
				</div>
				<div class="banner_top_right wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
					<nav class="navbar navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				
				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav cl-effect-14">
					<?php
							include('process.php');
					?>
					
					</ul>
				</div><!-- /.navbar-collapse -->	
				
			</nav>
				</div>
				<div class="clearfix"> </div>
			</div>
			<!-- banner -->
		
		</div>
	</div>
<!-- //banner -->


   <!--<h1 class="agile_head text-center"> Simple Login and Signup Form</h1>-->

   <div class="w3layouts_main wrap">
    <!--Horizontal Tab-->
    
        <div id="parentHorizontalTab_agile" style="width:720">
            <ul class="resp-tabs-list hor_1">
                <li>Hosts :</li>
                <!--<li>Apply Filters</li>-->
            </ul>
            <div class="resp-tabs-container hor_1">
               <div class="w3_agile_login">
			   <div class="agile_its_registration">
                <?php
				$fd = $_POST['fd'];
				$td= $_POST['tde'];
				$city = $_POST['to'];

				//echo $fd;
				$sql = "SELECT * FROM  `host` WHERE from_date <= '$fd' and to_date >= '$td'  and city_name='$city' LIMIT 0 , 30";//ORDER BY  `host`.`host_id` DESC";
				//echo $sql;
			$q=mysql_query($sql);
$no=0;
while($res=mysql_fetch_array($q))
{
$no=$no+1; ?>	
				<table>
					<tr>
						<td width="5000" style="padding-top:0px;"><img src="<?php echo 'data:image;base64,'.$res[12].' '; ?>" height="150" width="250" />
						
						<td width="800" style="padding-top:0px; padding-left:10px; margin-left:5px;">Address :<br> <?php echo $res[4]; ?> <br>
						Number Of room :<br> <?php echo $res[7]; ?> <br>
						Price :<br> <?php echo $res[8]; ?> <br>
						House Type :<br> <?php echo $res[9]; ?><br>
						From Date:<br>
						<?php echo $res[2]; ?><br>
						To Date:<br>
						<?php echo $res[3]; ?>
						</td>
					</tr>
					

		
		
	<div style="margin-top: 100px;">
	<a href="cs_book.php"><button type="button" name="book"  class=" btn-lg btn-primary" >Book-Room</button></a>
	</div>
	<div style="margin-top: 100px;">
	<a href="cs_view.php"><button type="button" name="book"  class=" btn-lg btn-primary" >View preference</button></a>
	</div>
		<?php
		echo"<hr>";
	
	}
?>

	

	
	
	
	
	
	
	
				</table>
				<hr>
			<?php
				}
				?>
					</div>
                </div>
             	</div>
            </div>
        </div>
		 <!-- //Horizontal Tab -->
    </div>
	<div class="agileits_w3layouts_copyright text-center">
			<!--<p><a href="//w3layouts.com/">W3layouts</a></p>-->
	</div>
<!--tabs-->
<script src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	//Horizontal Tab
	$('#parentHorizontalTab_agile').easyResponsiveTabs({
		type: 'default', //Types: default, vertical, accordion
		width: 'auto', //auto or any width like 600px
		fit: true, // 100% fit in a container
		tabidentify: 'hor_1', // The tab groups identifier
		activate: function(event) { // Callback function if tab is switched
			var $tab = $(this);
			var $info = $('#nested-tabInfo');
			var $name = $('span', $info);
			$name.text($tab.text());
			$info.show();
		}
	});
});
</script>
<script type="text/javascript">
		window.onload = function () {
			document.getElementById("password1").onchange = validatePassword;
			document.getElementById("password2").onchange = validatePassword;
		}
		function validatePassword(){
			var pass2=document.getElementById("password2").value;
			var pass1=document.getElementById("password1").value;
			if(pass1!=pass2)
				document.getElementById("password2").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("password2").setCustomValidity('');	 
				//empty string means no validation error
		}

</script>
<!--//tabs-->
</body>
</html>

<?php

