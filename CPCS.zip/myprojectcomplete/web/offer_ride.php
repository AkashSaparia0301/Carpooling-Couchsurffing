<?php
	include('conn.php');
?>

<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE html>

<html>
<head>
<title>KNOCK</title>
<style type="text/css">
    .box{
        
        display: none;
    }
    
    </style>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Simple Login and Signup Form web template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->

<link href="css/style10.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/mislider.css" rel="stylesheet" type="text/css" />
<link href="css/test.css" rel="stylesheet" type="text/css" />
<link href="css/mislider-custom.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /> 

<!-- Bootstrap-Core-CSS -->

<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /> <!-- Style-CSS --> 
<link rel="stylesheet" href="css/font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->

<!-- js -->
<script src="js/jquery-1.9.1.min.js"></script>
<!--// js -->

<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />
 <link href="//fonts.googleapis.com/css?family=Questrial" rel="stylesheet">
 <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('input[type="radio"]').click(function(){
        var inputValue = $(this).attr("value");
        var targetBox = $("." + inputValue);
        $(".box").not(targetBox).hide();
        $(targetBox).show();
    });
});
</script>
</head>


<body class="bg agileinfo">
<!-- banner -->
	<!--<div class="banner-2 wthree">-->
		<div class="container">
			<div class="banner_top">
				<div class="logo wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
					<h1><a href="index.html"><span>K</span>nock</a></h1>
				</div>
				<div class="banner_top_right wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
					<nav class="navbar navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav cl-effect-14">
					<?php
					include('process.php');
					?>
					
						<!--<li><a href="index.php">Home</a></li>
						<li><a href="about.php">About Us</a></li>
						<li><a href="carpool.php" class="active">Carpooling</a></li>
						<li><a href="couchsurfing.php">Couch_Surfing</a></li>
						<li><a href="gallery.php">Gallery</a></li>
						<li><a href="contact.php">Contact Us</a></li>
						<li><a href="login.php">login</a></li>-->
					</ul>
				</div><!-- /.navbar-collapse -->	
				
			</nav>
				</div>
				<div class="clearfix"> </div>
			</div>
			<!-- banner -->
		
		</div>
	</div>
<!-- //banner -->

   <!--<h1 class="agile_head text-center"> Simple Login and Signup Form</h1>-->
   <div class="w3layouts_main wrap">
    <!--Horizontal Tab-->
        <div id="parentHorizontalTab_agile">
            <ul class="resp-tabs-list hor_1">
                <li>Offer Ride</li>
                <li> Car info & Provided Facilities</li>
            </ul>
            <div class="resp-tabs-container hor_1">
               <div class="w3_agile_login">
			   <div class="agile_its_registration">
                    <form action="offer_proc.php" method="POST" class="agile_form" enctype="multipart/form-data">

					  <p>where Are you Heading ?:</p>
					<!-- <input required="required" onfocus="if (this.value=='Enter the full Address') this.value = ''" type="text"  value="Enter the full Address"  name="heading"/>-->

					<?php

					$sql="select city_name from city";
					$result=mysql_query($sql);

					?>
					<select required="required" onfocus="if(this.value'city') this.value=''" type="text" value="city" name="heading">

					<?php
					while($row=mysql_fetch_array($result))
					{

						echo "<option value='".$row['city_name']."'>".$row['city_name']."</option>";
					}
					?>
					</select>


					  <p>where Are you Leaving From ?:</p>
					  <?php
					$sql="select city_name from city";
					$result=mysql_query($sql);
					?>
					<select required="required" onfocus="if(this.value'city') this.value=''" type="text" value="city" name="leaving">

					<?php
					while($row=mysql_fetch_array($result))
					{

						echo "<option value='".$row['city_name']."'>".$row['city_name']."</option>";
					}
					?>
					</select>

					
					<!-- <input required="required" onfocus="if (this.value=='Enter the full Address') this.value = ''" type="text"  value="Enter the full Address"  name="leaving"/>-->
					  
					<!--  <p>Email:</p>
					  <input required="required" onfocus="if (this.value=='ex:yourmail@gmail.com') this.value = ''" type="text"  value="ex:yourmail@gmail.com" name="email" />-->
					  
					 <!-- <p>Contact Number:</p>
					  <input required="required"onfocus="if (this.value=='Your Number Goes here..') this.value = ''" type="text"  value="Your Number Goes here.." name="contactnumber"/>-->
					  
					  <p>When You are Going ?</p>
					 <!-- <input required="required"onfocus="if (this.value=='dd-mm-yyyy') this.value = ''" type="date"  value="dd-mm-yyyy" name="departuredate" />-->
					 <input type="date"  id="myDate" name="departuredate" min="2017-11-27">
					 
					
					  
					  <p>What time will you pick passangers up ?</p>
					 <input required="required" onfocus="if(this.value=='Time') this.value=''"  type="time" name="departuretime" value="Time"/>
					 
					  <p> Want your pasangers to be comfortable ? Keep middle seat empty:</p>
					  <select required="required" onfocus="if (this.value=='middleseat') this.value=''" type="text" value="middleseat" name="middleseat" />
					  <option value="yes">yes</option>
					  <option value="no">No,i will squees in 3</option>
					  </select>

					  <!--<p>Submit Photo of your Car:</p>
					  <input required="required" onfocus="if (this.value=='photo') this.value=''" type="file" value="photo" name="photo"/>-->


					  <p> How many persons will you take ?</p>
					  <input required="required" onfocus="if (this.value=='') this.value=''" type="text" value="" name="noofseat"/>

					  <p> Per Person cost ?</p>
					  <input required="required" onfocus="if (this.value=='') this.value=''" type="text" value="" name="per_person_cost"/>
					  <p>Type of Journey:</p>
					  <input type="radio" name="type_of_journey" value="single">Single</input>
					  <br>
					  <input type="radio" name="type_of_journey" value="round_trip">Round trip</input>

					  	
					 
						<!--<p> Return Date:</p>
					  	<!--<input onfocus="if (this.value=='dd-mm-yyyy') this.value = ''" type="date"  value="dd-mm-yyyy" name="returndate" />-->
					 	 <!--<input type="date" onclick="myFunction4()" id="myDate" name="returndate" min="2017-09-16">
					 	<script>
						function myFunction4()
						{
							var x= document.getElementById("myDate").min="2017-09-16";
							document.getElementById("demo").innerHTML =" THE value of min attribute was changed from '1980-01-01' to '1999-01-01'.";
						}
					 	</script>
					  
					  	<p> Return Time:</p>
					  	<input onfocus="if (this.value=='Time') this.value = ''" type="time"  value="Time" name="returntime" />
					  	
					 

					 <div class="red box"><p> Return Date:</p>
					  	<!-<input onfocus="if (this.value=='dd-mm-yyyy') this.value = ''" type="date"  value="dd-mm-yyyy" name="returndate" />-->

					  <!-- <p>Source City:</p>
					 <input required="required" name="sourcecity" onfocus="if (this.value=='source city') this.value = ''" type="text"  value="source city" />
					 
					   <p>Destnation City:</p>
					 <input required="required" name="destinationcity" onfocus="if (this.value=='destination city') this.value = ''" type="text"  value="destination city" />-->
					 
					<!-- <p> Pickup Address:</p>
					  <textarea required="required"onfocus="if (this.value=='Address') this.value = ''" type="text"  value="Address" name="pickupaddress" ></textarea>
					  
					 <p> Destination Address:</p>
					  <textarea required="required"onfocus="if (this.value=='Address') this.value = ''" type="text"  value="Address" name="destinationaddress"></textarea>-->
					 
					<!-- <p>Journey:</p>
					  <select required="required"onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" name="journey"/>
					  <option value="single">Single</option>
					  <option value="round trip">Round Trip</option>
					 
					  </select>-->
					 <!-- <p>Per Person Cost*:</p>
					 <input required="required"onfocus="if (this.value=='cost') this.value = ''" type="text"  value="cost" name="perpersoncost"/>-->
					 <div class="round_trip box"><p> Return Date:</p>
					  	
					 	 <input type="date" onclick="myFunction4()" id="myDate" name="returndate" min="2017-09-16">
					 	<script>
						function myFunction4()
						{
							var x= document.getElementById("myDate").min="2017-09-16";
							document.getElementById("demo").innerHTML =" THE value of min attribute was changed from '1980-01-01' to '1999-01-01'.";
						}
					 	</script>
					  
					  	<p> Return Time:</p>
					  	<input onfocus="if (this.value=='Time') this.value = ''" type="time"  value="Time" name="returntime" /></div>
					 
					 <p>Driving Licence No*:</p>
					 <input required="required"onfocus="if (this.value=='Driving Licence No') this.value = ''" type="text"  value="Driving Licence No" name="drivinglicencenumber"/>
					 
					 <p>Images of car</p>
					 <input type=file name="file">
					 
					  <input onclick="myFunction()" type="submit" value="offerride" class="agileinfo" name="offerride"/>
					  <script>
			
		 				 function myFunction()
					  {
						  alert("YOUR RIDE HAS BEEN SUCCESSFULLY OFFERED");
					  }
					  </script>

					  					</form>
					</div>
					
             









                </div>
                <div class="agile_its_registration">
                    <form action="offer_proc.php" method="POST" class="agile_form">
					<!--<input type="checkbox" name="verified"  value="verified"> Verfied<br>
					  <input type="checkbox" name="ac" value="ac"> AC<br>
					  <input type="checkbox" name="non_ac" value="non_ac"> NON-AC<br>-->
					  
					  <p>Car Name:</p>
					  <input onfocus="if (this.value=='Name') this.value = ''" type="text"  value="Name"  name="name"/>
					 
					<p>Car Model:</p>
					  <input onfocus="if (this.value=='Model') this.value = ''" type="text"  value="Model" name="model"/>
					 
					 <p>Make Year:</p>
					  <input onfocus="if (this.value=='Make Year') this.value = ''" type="text"  value="Make Year" name="make_year" />
					 <p>Number Plate:</p>
					  <input required="required"onfocus="if (this.value=='Number Plate goes here..') this.value = ''" type="text"  value="Number Plate goes here.." name="number_plate"/>
					 
					 
					 <p>Type of car:</p>
					  <input  onfocus="if (this.value=='Type of Car') this.value = ''" type="text"  value="Type of Car" name="type_of_car"/>
					
					<p>Color Of Car:</p>
					  <input  onfocus="if (this.value=='Color of car goes here..') this.value = ''" type="text"  value="Color of car goes here.." name="color"/><br>
					
					<!--<p>No Of Seats Offered*</p>
					  <input required="required" onfocus="if (this.value=='No Of Seats Offered') this.value = ''" type="text"  value="No Of Seats Offered" name="noofseatsoffered"/>-->

					 
					 <p>AC/NON AC:</p>
					  <select onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" name="ac_nonac"/>
					  <option value="AC">AC</option>
					  <option value="Non AC">NON AC</option>
					  <option value="both">Both</option>
					  </select>
					 
					  <p>Gender Selection:</p>
					  <select onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" name="gender"/>
					  <option value="male">Male</option>
					  <option value="female">Female</option>
					  <option value="both">Both</option>
					  </select>
					 
					  <p>Pet Allowed:</p>
					  <select required="required" name="pet" onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					  </select>
					  
					  
					  
					  <p>Kids Allowed:</p>
					  <select required="required" name="kid" onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">YES</option>
					  <option value="no">No</option>
				
					  </select>
					  
					  <p>Music Allowed:</p>
					  <select required="required" name="music" onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					  <p>Smoking Allowed:</p>
					  <select required="required" name="smoking" onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no peference">No Preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					  </select>
					  
					  <p>First-aid-Available:</p>
					  <select required="required" name="firstaid" onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  <p>Window Seat Offered:</p>
					  <select required="required" name="window" onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  <p>Luggage Size:</p>
					  <select required="required" name="luggage" onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="large">large</option>
					  <option value="small">small</option>
					  <option value="medium">Medium</option>
					 
					  </select>
					   
					   <p>WI-FI Offered:</p>
					  <select required="required" name="wifi" onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					  </select>
				
					   <input type="submit" value="Submit Info" name="submitinfo"/>
					   <input type="reset" value="Reset" />
					</form> 
				</div>
            </div>
        </div>
		 <!-- //Horizontal Tab -->
    </div>
	<div class="agileits_w3layouts_copyright text-center">
			<!--<p><a href="//w3layouts.com/">W3layouts</a></p>-->
	</div>
<!--tabs-->
<script src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	//Horizontal Tab
	$('#parentHorizontalTab_agile').easyResponsiveTabs({
		type: 'default', //Types: default, vertical, accordion
		width: 'auto', //auto or any width like 600px
		fit: true, // 100% fit in a container
		tabidentify: 'hor_1', // The tab groups identifier
		activate: function(event) { // Callback function if tab is switched
			var $tab = $(this);
			var $info = $('#nested-tabInfo');
			var $name = $('span', $info);
			$name.text($tab.text());
			$info.show();
		}
	});
});
</script>
<script type="text/javascript">
		window.onload = function () {
			document.getElementById("password1").onchange = validatePassword;
			document.getElementById("password2").onchange = validatePassword;
		}
		function validatePassword(){
			var pass2=document.getElementById("password2").value;
			var pass1=document.getElementById("password1").value;
			if(pass1!=pass2)
				document.getElementById("password2").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("password2").setCustomValidity('');	 
				//empty string means no validation error
		}

</script>
<script>

</script>
<!--//tabs-->
</body>
</html>

