<?php
include('conn.php');
include('find_ride_proc.php');
?>

<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>KNOCK</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Simple Login and Signup Form web template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/find.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/mislider.css" rel="stylesheet" type="text/css" />
<link href="css/test.css" rel="stylesheet" type="text/css" />
<link href="css/mislider-custom.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /> 

<!-- Bootstrap-Core-CSS -->

<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /> <!-- Style-CSS --> 
<link rel="stylesheet" href="css/font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->
<!-- js -->
<script src="js/jquery-1.9.1.min.js"></script>
<!--// js -->
<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />
 <link href="//fonts.googleapis.com/css?family=Questrial" rel="stylesheet">
</head>
<body class="bg agileinfo">
<!-- banner -->
	<!--<div class="banner-2 wthree">-->
		<div class="container">
			<div class="banner_top">
				<div class="logo wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
					<h1><a href="index.html"><span>K</span>nock</a></h1>
				</div>
				<div class="banner_top_right wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
					<nav class="navbar navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav cl-effect-14">
					<?php
						include('process.php');
					?>
						<!--<li><a href="index.php">Home</a></li>
						<li><a href="about.php">About Us</a></li>
						<li><a href="carpool.php" class="active">Carpooling</a></li>
						<li><a href="couchsurfing.php">Couch_Surfing</a></li>
						<li><a href="gallery.php">Gallery</a></li>
						<li><a href="contact.php">Contact Us</a></li>
						<li><a href="login.php">login</a></li>-->
					</ul>
				</div><!-- /.navbar-collapse -->	
				
			</nav>
				</div>
				<div class="clearfix"> </div>
			</div>
			<!-- banner -->
		
		</div>
	</div>
<!-- //banner -->

   <!--<h1 class="agile_head text-center"> Simple Login and Signup Form</h1>-->
   <div class="w3layouts_main wrap">
    <!--Horizontal Tab-->
        <div id="parentHorizontalTab_agile">
            <ul class="resp-tabs-list hor_1">
                <li>Find Ride</li>
                <!--<li>Apply Filters</li>-->
            </ul>
            <div class="resp-tabs-container hor_1">
               <div class="w3_agile_login">
			   <div class="agile_its_registration">
                    <form action="request.php" method="GET" class="agile_form">
					  <p>Leaving From :</p>
					<!-- <input required="required"onfocus="if (this.value=='Leaving from...(Specific location)') this.value = ''" type="text"  value="Leaving from...(Specific location)" name="leavingfrom" />-->
					<?php
					$sql="select city_name from city";
					$result=mysql_query($sql);
					?>
					<select required="required" onfocus="if(this.value'city') this.value=''" type="text" value="city" name="leavingfrom">

					<?php
					while($row=mysql_fetch_array($result))
					{

						echo "<option value='".$row['city_name']."'>".$row['city_name']."</option>";
					}
					?>
					</select>
					
				<!--	<select name="leavingfrom">
					<?php
					/*$sql=mysql_query("select * from source_city");
					while($row=mysql_fetch_array($sql))
					{
						echo "<option value=\"leavingfrom\">" .$row['source_city']. "</option>";
					}*/
					?>
					</select>-->
					<p>Going to:</p>
					
					  <!--<input required="required"onfocus="if (this.value=='Going To...(Specific location)') this.value = ''" type="text"  value="Going To...(Specific location)" name="goingto"/>-->

					  <?php
					$sql="select city_name from city";
					$result=mysql_query($sql);
					?>
					<select required="required" onfocus="if(this.value'city') this.value=''" type="text" value="city" name="goingto">

					<?php
					while($row=mysql_fetch_array($result))
					{

						echo "<option value='".$row['city_name']."'>".$row['city_name']."</option>";
					}
					?>
					</select>
					
					 
					 <p>Travel Date :</p>
					 <!--<input  onfocus="if (this.value=='dd-mm-yyyy') this.value = ''" type="date" value="dd-mm-yyyy" name="createdon">-->
					 <input type="date" onclick="myFunction4()" id="myDate" name="traveldate" min="2017-09-16">
					 <script>
						function myFunction4()
						{
							var x= document.getElementById("myDate").min="2017-09-16";
							document.getElementById("demo").innerHTML =" THE value of min attribute was changed from '1980-01-01' to '1999-01-01'.";
						}
					 </script>
					 <p>Travel Start Time :</p>
					 <input  onfocus="if (this.value=='dd-mm-yyyy') this.value = ''" type="time" value="dd-mm-yyyy" name="travelstarttime">
					  <p>Numbers Of Travelers :</p>
					  <select required="required" onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" name="numberoftravelers"/>
					  <option value="1">1</option>
					  <option value="2">2</option>
					  <option value="3">3</option>
					  <option value="4">4</option>
					  <option value="5">5</option>
					  <option value="6">6</option>
					  <option value="7">7</option>
					  </select>
					  <input type="submit" name="FindRide"value="Find Ride" class="agileinfo" />
					</form>
					</div>
					 <!--<div class="login_w3ls">
				        <a href="#">Forgot Password</a>
					 </div>-->
                    
                </div>
                <div class="agile_its_registration">
                   <!-- <form action="#" method="POST" class="agile_form">
					  <input type="checkbox" name="verified"  value="verified"> Verified <br>
					  <input type="checkbox" name="ac" value="Bike"> AC <br>
					  <input type="checkbox" name="non_ac" value="Bike"> NON-AC <br>
					  <input type="checkbox" name="first_aid"  value="Bike"> Is First-Aid Provided? <br>
					  <br>
					  <p>Gender Selection :</p>
					  <select required="required" name="gender" onfocus="if (this.value=='Gender Selection') this.value = ''" type="text"  value="Gender Selection" />
					  <option value="1">Male</option>
					  <option value="2">Female</option>
					  <option value="2">Other</option>
					  </select>
					  <p>Smoking Allowed :</p>
					  <select required="required" name="smoking" onfocus="if (this.value=='Gender Selection') this.value = ''" type="text"  value="Gender Selection" />
					  <option value="1">No Preference</option>
					  <option value="2">Yes</option>
					  <option value="2">No</option>
					  </select>
					  <p>Pet Allowed :</p>
					  <select required="required" name="pet" onfocus="if (this.value=='Gender Selection') this.value = ''" type="text"  value="Gender Selection" />
					  <option value="1">No Preference</option>
					  <option value="2">Yes</option>
					  <option value="2">No</option>
					  </select>
					  <p>Kids Allowed :</p>
					  <select required="required" name="kid" onfocus="if (this.value=='Gender Selection') this.value = ''" type="text"  value="Gender Selection" />
					  <option value="1">No Preference</option>
					  <option value="2">Yes</option>
					  <option value="2">No</option>
					  </select>
					  <p>Music Selection :</p>
					  <select required="required" name="music" onfocus="if (this.value=='Gender Selection') this.value = ''" type="text"  value="Gender Selection" />
					  <option value="1">No Preference</option>
					  <option value="2">Yes</option>
					  <option value="2">No</option>
					  </select>
					  <p>Luggage Selection :</p>
					  <select required="required" name="luggage" onfocus="if (this.value=='Gender Selection') this.value = ''" type="text"  value="Gender Selection" />
					  <option value="1">Large</option>
					  <option value="2">Small</option>
					  <option value="2">Medium</option>
					  </select>
					  <p>Window Seat Selection :</p>
					  <select required="required" name="window" onfocus="if (this.value=='Gender Selection') this.value = ''" type="text"  value="Gender Selection" />
					  <option value="1">No Preference</option>
					  <option value="2">Yes</option>
					  <option value="2">No</option>
					  </select>

					  
					  <!--<input type="text" name="username" required="required" />
					  <p>Email</p>
					  <input type="email" name="email" required="required" />
					  <p>Password</p>
					  <input type="password" name="Password" id="password1"  required="required">
					  <p>Confirm Password</p>
					  <input type="password" name="Confirm Password" id="password2"  required="required">
         	  			<div class="check w3_agileits">
							<label class="checkbox w3"><input type="checkbox" name="checkbox" required="required" ><i> </i>I accept the terms and conditions</label>
						</div>-->
					   <!--<input type="submit" name="apply" value="Apply Filters"/>
					   <input type="reset" value="Reset" />
					</form> -->
				</div>
            </div>
        </div>
		 <!-- //Horizontal Tab -->
    </div>
	<div class="agileits_w3layouts_copyright text-center">
			<!--<p><a href="//w3layouts.com/">W3layouts</a></p>-->
	</div>
<!--tabs-->
<script src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	//Horizontal Tab
	$('#parentHorizontalTab_agile').easyResponsiveTabs({
		type: 'default', //Types: default, vertical, accordion
		width: 'auto', //auto or any width like 600px
		fit: true, // 100% fit in a container
		tabidentify: 'hor_1', // The tab groups identifier
		activate: function(event) { // Callback function if tab is switched
			var $tab = $(this);
			var $info = $('#nested-tabInfo');
			var $name = $('span', $info);
			$name.text($tab.text());
			$info.show();
		}
	});
});
</script>
<script type="text/javascript">
		window.onload = function () {
			document.getElementById("password1").onchange = validatePassword;
			document.getElementById("password2").onchange = validatePassword;
		}
		function validatePassword(){
			var pass2=document.getElementById("password2").value;
			var pass1=document.getElementById("password1").value;
			if(pass1!=pass2)
				document.getElementById("password2").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("password2").setCustomValidity('');	 
				//empty string means no validation error
		}

</script>
<!--//tabs-->
</body>
</html>

