<?php
session_start();
if(isset($_SESSION['username']))
{

include('conn.php');
$mid = $_SESSION['uid'];
if(isset($_POST['becomehost']))
{
		$fdate=$_POST['fdate'];
		$tdate=$_POST['tdate'];
		$address=$_POST['address'];
		$city=$_POST['city'];
		$areacode=$_POST['areacode'];
		$noofrooms=$_POST['noofrooms'];
		$cost=$_POST['cost'];
		$typeofhouse=$_POST['typeofhouse'];
		$typeofroom=$_POST['typeofroom'];
		$furniture=$_POST['furniture'];
		/*$image = addslashes($_FILES['image']['tmp_name']);
		$name = addslashes($_FILES['image']['name']);
		$image = file_g1et_contents($image);
		$image = base64_encode($image);*/

		$file=$_FILES["file"]["name"];
		move_uploaded_file($_FILES['file']['tmp_name'],"images/".$_FILES['file']['name']);

		$sql="insert into `host` values('',$mid,'$fdate','$tdate','$address','$city',$areacode,$noofrooms,$cost,'$typeofhouse','$typeofroom','$furniture','$file')";
		
		$result=mysql_query($sql);
		if($result)
		{
			echo '<script type="text/javascript"> alert("Couch Hosted ..."); </script>';
		}
		else
		{
			echo '<script type="text/javascript"> alert("Something went wrong!"); </script>';
		}
}

?>
	

<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->


<!DOCTYPE html>


<html>
<head>
<title>KNOCK</title>
<script type="text/javascript">
function CheckColors(val){
 var element=document.getElementById('language_t');
 if(val=='No Preference'||val=='Others')
   element.style.display='block';
 else  
   element.style.display='none';
}
</script>

<!-- custom-theme -->

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Simple Login and Signup Form web template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>

<!-- //custom-theme -->


<link href="css/style10.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/mislider.css" rel="stylesheet" type="text/css" />
<link href="css/test.css" rel="stylesheet" type="text/css" />
<link href="css/mislider-custom.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /> 
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /> <!-- Style-CSS --> 
<link rel="stylesheet" href="css/font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->

<!-- js -->
<script src="js/jquery-1.9.1.min.js"></script>
<!--// js -->

<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />
 <link href="//fonts.googleapis.com/css?family=Questrial" rel="stylesheet">
</head>


<body class="bg agileinfo">
<div class="container">
			<div class="banner_top">
				<div class="logo wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
					<h1><a href="index.html"><span>K</span>nock</a></h1>
				</div>
				<div class="banner_top_right wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
					<nav class="navbar navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				
				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav cl-effect-14">
					<?php
						include('process1.php');
					?>
						<!--<li><a href="index.php">Home</a></li>
						<li><a href="about.php">About Us</a></li>
						<li><a href="carpool.php">Carpooling</a></li>
						<li><a href="couchsurfing.php" class="active">Couch_Surfing</a></li>
						<!--<li><a href="services.html">Services</a></li>
						<li><a href="gallery.php">Gallery</a></li>
						<!--<li><a href="codes.html">Codes</a></li>
						<li><a href="contact.php">Contact Us</a></li>
						<li><a href="index1.php">Log Out</a></li>-->
					</ul>
				</div><!-- /.navbar-collapse -->	
				
			</nav>
				</div>
				<div class="clearfix"> </div>
			</div>
			<!-- banner -->
		
		</div>
	</div>
<!-- //banner -->
				
   <!--<h1 class="agile_head text-center"> Simple Login and Signup Form</h1>-->
   <div class="w3layouts_main wrap">
    <!--Horizontal Tab-->
        <div id="parentHorizontalTab_agile">
            <ul class="resp-tabs-list hor_1">
                <li>Become Host</li>
                <li> Home Info & Provided Facilities</li>
            </ul>
            <div class="resp-tabs-container hor_1">
               <div class="w3_agile_login">
			   <div class="agile_its_registration">
                    <form action="become_host.php" method="post" class="agile_form" enctype="multipart/form-data">
                    		<input type="hidden" name="host_id" >
					  <!--<p>Name*</p>
					  <input required="required" name="name" onfocus="if (this.value=='Name') this.value = ''" type="text"  value="Name" />

					  
					  <p>Email*</p>
					  <input required="required" name="email" onfocus="if (this.value=='ex:yourmail@gmail.com') this.value = ''" type="text"  value="ex:yourmail@gmail.com" />-->

					  <p>Availability of Room:</p>
					  <br>

					  <p>From*</p>
					  <input required="required" name="fdate" onFocus="if (this.value=='dd-mm-yyyy') this.value = ''" type="date"  value="dd-mm-yyyy" />

					  <p>To*</p>
					  <input required="required" name="tdate" onFocus="if (this.value=='dd-mm-yyyy') this.value = ''" type="date"  value="dd-mm-yyyy" />
					  
					 <!-- <p>Phone Number:</p>
					  <input required="required" name="phonenumber"onfocus="if (this.value=='PhoneNumber') this.value = ''" type="text"  value="PhoneNumber" />-->

					  <p>Address:</p>
					  <textarea required="required" name="address" onFocus="if (this.value=='Enter your Full Address') this.value = ''" type="text"  value="Enter your Full Address" >
					 </textarea>
					 
					  <p>City:</p>
					<!--  <input required="required" name="city" onfocus="if (this.value=='city') this.value = ''" type="text"  value="city" />-->
					<?php
					$sql="select city_name from city";
					$result=mysql_query($sql);
					?>
					<select required="required" onFocus="if(this.value'city') this.value=''" type="text" value="city" name="city">

					<?php
					while($row=mysql_fetch_array($result))
					{

						echo "<option value='".$row['city_name']."'>".$row['city_name']."</option>";
					}
					?>
					</select>

					  <p>AreaCode:</p>
					  <input required="required" name="areacode" onFocus="if (this.value=='AreaCode') this.value = ''" type="text"  value="AreaCode" maxlength="6" />
					  
					  
					  <!--<p>State:</p>
					  <input required="required" name="state"onfocus="if (this.value=='state') this.value = ''" type="text"  value="state" /><!--<input type="password" name="username" required="required" class="password" /> -->
					  
					 <!-- <p>Country:</p>
					  <input required="required" name="country"onfocus="if (this.value=='country') this.value = ''" type="text"  value="country" />-->
					 
						
					 <p>Number Of Rooms:</p>
					  <input required="required" name="noofrooms" onFocus="if (this.value=='') this.value = ''" type="text"  value="" />

					  <p>Cost:</p>
					  <input required="required" name="cost" onFocus="if (this.value=='Enter Per Room Cost') this.value = ''" type="text"  value="Enter Per Room Cost" />

					  <p>Type of House *</p>
					  <input required="required"  name="typeofhouse" onFocus="if (this.value=='Ex:Row House,Appartment,Bunglow') this.value = ''" type="text"  value="Ex:Row House,Appartment,Bunglow" />
					  
					  <p>Type of Room:</p>
					  <select required="required" name="typeofroom" onFocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="Private">Private</option>
					  <option value="Public">Public</option>
					  <option value="Shared">Shred</option>
					 
					  </select>


					   <p>Furniture Available ?:</p>
					  <select required="required" name="furniture" onFocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="yes">Yes</option>
					  <option value="No">No</option>
					  <option value="No preference">No preference</option>
					 
					  </select><br>
					<br><p>House images</p>
					<input type="file" name="file"><br><br>
					 <!-- <p>Room Type:</p>
					  <select required="required" name="roomtype"onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="Private">Private</option>
					  <option value="Public">Public</option>
					  <option value="Shared">Shared</option>
					  </select>-->
	  				<input type="submit" value="Become1 Host" class="agileinfo" name="becomehost"/>
					</form>
					</div>
                    
                </div>
                <div class="agile_its_registration">
                    <form action="become_host_proc.php" method="GET" class="agile_form">
					 <!-- <input type="checkbox" name="verified"  value="verified"> Verified<br>
					  <input type="checkbox" name="ac" value="ac"> AC<br>
					  <input type="checkbox" name="nonac" value="nonac"> NON AC<br>
					  <input type="checkbox" name="wheelchair"  value="wheelchair">Wheelchair Accessible <br>-->
					  
					 <!--  <p>Type of House *</p>
					  <input required="required"  name="typeofhouse" onfocus="if (this.value=='Ex:Row House,Appartment,Bunglow') this.value = ''" type="text"  value="Ex:Row House,Appartment,Bunglow" />
					  

					  <!--<p>House Name/No *</p>
					  <input required="required"  name="housenameno" onfocus="if (this.value=='Name or Number of house goes here') this.value = ''" type="text"  value="Name or Number of house goes here" />-->


					  <!-- <p>Type of Room:</p>
					  <select required="required" name="typeofroom" onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="Private">Private</option>
					  <option value="Public">Public</option>
					  <option value="Shared">Shred</option>
					 
					  </select>

					   <p>Furniture Available ?:</p>
					  <select required="required" name="furniture" onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="yes">Yes</option>
					  <option value="No">No</option>
					  <option value="No preference">No preference</option>
					 
					  </select><br>

						<!--<input type="checkbox" name="ch[]"  value="verified"> Verified<br>
					  <input type="checkbox" name="ch[]" value="ac"> AC<br>
					  <input type="checkbox" name="ch[]" value="nonac"> NON AC<br>-->
					  
					  <p>Wheelchair Accessible</p>
					  <select required="required" name="wheelchair" onFocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="YES">YES</option>
					  <option value="NO">NO</option>
					  <option value="NO-Preference">NO-Preference</option>
					  </select>

					  <p>AC/NON-AC:</p>
					  <select required="required" name="ac_nonac" onFocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="AC">AC</option>
					  <option value="NON AC">NON AC</option>
					  <option value="Both">Both</option>
					  </select>
					 
					
					  <p>Gender Selection:</p>
					  <select required="required" name="gender" onFocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="male">Male</option>
					  <option value="female">Female</option>
					  <option value="both">Both</option>
					 
					  </select>
					 
					  <p>Pet Allowed:</p>
					  <select required="required" name="pet" onFocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					  </select>
					  
					  <p>Kids Allowed:</p>
					  <select required="required" name="kid" onFocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">YES</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					  <p>Music Allowed:</p>
					  <select required="required" name="music" onFocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					  <p>Smoking Allowed:</p>
					  <select required="required" name="smoking" onFocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					  <p>Drinking Allowed:</p>
					  <select required="required" name="drinking" onFocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No Preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					   <p>Food Offered:</p>
					  <select required="required" name="food" onFocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					   
					   <p>WI-FI Offered:</p>
					  <select required="required" name="wifi" onFocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					   
					   <p>Vehicle Offered:</p>
					  <select required="required" name="vehicle" onFocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />
					  <option value="no preference">No preference</option>
					  <option value="yes">Yes</option>
					  <option value="no">No</option>
					 
					  </select>
					  
					  <!--<p>Language Spoken:</p>
					  <select required="required" name="language" onfocus="if (this.value=='Numbers Of Travelers') this.value = ''" type="text"  value="Numbers Of Travelers" />-->
					 
<p>Language Spoken:</p>
  <select  required="required"  onfocus="if (this.value=='Select your language') this.value = ''" type="text"  value="Select your language" name="language" onChange="CheckColors(this.value);"> 
   <option value="No Preference">No Preference</option>
					  <option value="English">English</option>
					  <option value="Hindi">Hindi</option>
					  <option value="Punjabi">Punjabi</option>
					  <option value="Telugu">Telugu</option>
					  <option value="Kannad">Kannad</option>
					  <option value="Tamil">Tamil</option>
					  <option value="Bengoli">Bengoli</option>
					  <option value="Gujarati">Gujarati</option>
					  <option value="Marathi">Marathi</option>
					  <option value="Others">Others</option>
					  
    
  </select>
<input type="text" name="language_txt" id="language_t" style='display:none;'/>
					  
					 
					   <input type="submit" name="submitinfo" value="Submit Info"/>
					   <input type="reset" value="Reset" />
					</form> 
				</div>
            </div>
        </div>
		 <!-- //Horizontal Tab -->
    </div>
	<div class="agileits_w3layouts_copyright text-center">
			<!--<p><a href="//w3layouts.com/">W3layouts</a></p>-->
	</div>


<!--tabs-->

<script src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	//Horizontal Tab
	$('#parentHorizontalTab_agile').easyResponsiveTabs({
		type: 'default', //Types: default, vertical, accordion
		width: 'auto', //auto or any width like 600px
		fit: true, // 100% fit in a container
		tabidentify: 'hor_1', // The tab groups identifier
		activate: function(event) { // Callback function if tab is switched
			var $tab = $(this);
			var $info = $('#nested-tabInfo');
			var $name = $('span', $info);
			$name.text($tab.text());
			$info.show();
		}
	});
});
</script>


<script type="text/javascript">
		window.onload = function () {
			document.getElementById("password1").onchange = validatePassword;
			document.getElementById("password2").onchange = validatePassword;
		}
		function validatePassword(){
			var pass2=document.getElementById("password2").value;
			var pass1=document.getElementById("password1").value;
			if(pass1!=pass2)
				document.getElementById("password2").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("password2").setCustomValidity('');	 
				//empty string means no validation error
		}

</script>
<!--//tabs-->

</body>
</html>

<?php

}
else
{
header("location:index.php");
}
?>