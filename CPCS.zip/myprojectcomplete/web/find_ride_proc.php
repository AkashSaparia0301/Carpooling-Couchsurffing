<?php
//SESSION_START();
	/*if(isset($_GET['apply']))
	{
		
		$verified=$_GET['verified'];
		$ac=$_GET['ac'];
		$non_ac=$_GET['non_ac'];
		$first_aid=$_GET['first_aid'];
		$gender=$_GET['gender'];
		$smoking=$_GET['smoking'];
		$pet=$_GET['pet'];
		$kid=$_GET['kid'];
		$music=$_GET['music'];
		$luggage=$_GET['luggage'];
		$window=$_GET['window'];
		
		
		
	}*/
	
	if(isset($_GET['FindRide']))
	{
		
		$_SESSION['leavingfrom']=$_GET['leavingfrom'];
		echo $_SESSION['leavingfrom'];
		echo $_SESSION['goingto']=$_GET['goingto'];
		echo $_SESSION['traveldate']=$_GET['traveldate'];
		echo $_SESSION['travelstarttime']=$_GET['travelstarttime'];
		echo $_SESSION['numberoftravelers']=$_GET['numberoftravelers'];
		header("location:request.php");
	
	}
?>
