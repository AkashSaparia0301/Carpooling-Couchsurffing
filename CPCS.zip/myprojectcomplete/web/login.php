<?php
	include('conn.php');
	include('login_poc.php');

	?>

<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->


<!DOCTYPE html>


<html>
<head>
<style>
/* The message box is shown when the user clicks on the password field */
#message {
    display:none;
    background: #0000;
    color: #ffc4c4;
    position: relative;
    padding: 20px;
    margin-top: 10px;
}

#message p {
    padding: 10px 35px;
    font-size: 18px;
}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
    color: green;
}

.valid:before {
    position: relative;
    left: -35px;
    content: "✔";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
    color: red;
}

.invalid:before {
    position: relative;
    left: -35px;
    content: "✖";
}
</style>
<title>KNOCK</title>


<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Simple Login and Signup Form web template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
		
		
<!-- //custom-theme -->
<link href="css/style1.css" rel="stylesheet" type="text/css" media="all" />


<!-- js -->
<script src="js/jquery-1.9.1.min.js"></script>
<!--// js -->
<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />
 <link href="//fonts.googleapis.com/css?family=Questrial" rel="stylesheet">
</head>


<body class="bg agileinfo">
   <!--<h1 class="agile_head text-center"> Simple Login and Signup Form</h1>-->
   <div class="w3layouts_main wrap">
    <!--Horizontal Tab-->
        <div id="parentHorizontalTab_agile">
		
            <ul class="resp-tabs-list hor_1">
                <li>LogIn</li>
                <li>SignUp</li>
            </ul>
			
            <div class="resp-tabs-container hor_1">
               <div class="w3_agile_login">
			   
			   
			   <?php
			   if(isset($_GET['msg'])=="err")
			   { ?>
				<p style="color:#FF0000;">Invalid Username Or Password</p>
				<?php } ?>
				
				
				<div class="agile_its_registration">
				
                    <form action="login.php" method="POST" class="agile_form">
					  <p>Username</p>
					  <input type="text" name="username" required="required" />
					  <p>Password</p>
					  <input type="password" name="password" required="required" class="password" /> 
					  <div class="check">
							<label class="checkbox w3l"><input type="checkbox" name="checkbox" required="required"><i> </i>I accept the terms and conditions</label>
					 </div>
					  <input  name="login" type="submit" value="log-in" class="agileinfo" />
					 
					  <input type="submit" value="reset" name="reset" class="agileinfo" />
					</form>
					
					 <div class="login_w3ls">
				        <a href="#">Forgot Password ?</a>
					 </div>
                    
                </div>
				</div>
				

                <div class="agile_its_registration">
                   
				   <form action="login.php" class="agile_form" method="POST">

				    <p>First name</p>
					  <input type="text" name="first_name" required="required" />
					  <p>Last name</p>
					  <input type="text" name="last_name" required="required" />
					  <p>Username</p>
					  <input type="text" name="username" required="required" />
					  <p>Email</p>
					  <input type="email" name="email" required="required" />
					  <p>Password</p>
					  <!--<input type="password" name="password" id="password1"  required="required">-->
					  <!--<label for="psw">Password</label>-->
    <input type="password" id="psw" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
    
   <!-- <input type="submit" value="Submit">
  </form>
</div>-->

<div id="message">
  <h3>Password must contain the following:</h3>
	<p id="letter" class="invalid">A <b>lowercase</b> letter</p>
	<p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
	<p id="number" class="invalid">A <b>number</b></p>
	<p id="length" class="invalid">Minimum <b>8 characters</b></p>
</div>
				
<script>
var myInput = document.getElementById("psw");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
    document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
    document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>

					  
					  
					  
					   <p>Contact Number</p>
					  <input type="text" pattern="[7-9]{1}[0-9]{9}" name="contact_number" maxlength="10"/>
					   <p>Gender</p>
					   <input type="radio" name="gender" value="Male">MALE</input>
					   <input type="radio" name="gender" value="Female">FEMALE</input>
					   <br>
					   
					  <!-- <p>Id - Proof : </p>
					   <input type="text" name="proof" required="requied">-->
					   
			 <input type="submit" value="sign-up" class="agileinfo" name="signup"/>
			 <input type="reset" value="Reset" class="agileinfo" name="reset"/>
			 
					   
					 
					</form> 
				</div>
            </div>
        </div>
		 <!-- //Horizontal Tab -->
    </div>
	<div class="agileits_w3layouts_copyright text-center">
			<!--<p><a href="//w3layouts.com/">W3layouts</a></p>-->
	</div>
	
	
<!--tabs-->
<script src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	//Horizontal Tab
	$('#parentHorizontalTab_agile').easyResponsiveTabs({
		type: 'default', //Types: default, vertical, accordion
		width: 'auto', //auto or any width like 600px
		fit: true, // 100% fit in a container
		tabidentify: 'hor_1', // The tab groups identifier
		activate: function(event) { // Callback function if tab is switched
			var $tab = $(this);
			var $info = $('#nested-tabInfo');
			var $name = $('span', $info);
			$name.text($tab.text());
			$info.show();
		}
	});
});
</script>


<script type="text/javascript">
		window.onload = function () {
			document.getElementById("password1").onchange = validatePassword;
			document.getElementById("password2").onchange = validatePassword;
		}
		function validatePassword(){
			var pass2=document.getElementById("password2").value;
			var pass1=document.getElementById("password1").value;
			if(pass1!=pass2)
				document.getElementById("password2").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("password2").setCustomValidity('');	 
				//empty string means no validation error
		}

</script>
<!--//tabs-->
</body>
</html>

