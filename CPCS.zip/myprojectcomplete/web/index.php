
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->


<!DOCTYPE html>


<html lang="en">
<head>
<title>KNOCK</title>


<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Auto Car Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--// Meta tag Keywords -->


<!-- css files -->
<link href="css/mislider.css" rel="stylesheet" type="text/css" />
<link href="css/mislider-custom.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /> 


<!-- Bootstrap-Core-CSS -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /> <!-- Style-CSS --> 
<link rel="stylesheet" href="css/font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->
<!-- //css files -->

<!-- online-fonts -->
<link href="//fonts.googleapis.com/css?family=Jockey+One&amp;subset=latin-ext" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Niconne&amp;subset=latin-ext" rel="stylesheet">
<!-- //online-fonts -->


<style> 
/*input[type=text] 
{
  	width: 130px;
    box-sizing: border-box;
	border:  solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    
	background-color: transparent;
	
    background-image: url();
	 
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}

input[type=text]:focus {
    width: 100%;
}*/
</style>
</head>
	
<body>

<!-- banner -->

<div class="banner wthree">
		<div class="container">
			<div class="banner_top">
		<!--<form>	 
				<input type="text" name="search" placeholder="Search.."   >
		</form>-->
	

				<div class="logo wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
					
		

					<h1><a href="index.php"><span>K</span>nock</a></h1>
				
				</div>
				<div class="banner_top_right wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
					<nav class="navbar navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav cl-effect-14">
					<?php
										include('process.php');
									

					?>
						<!--<li><a href="index.php" class="active">Home</a></li>
						<li><a href="about.php">About Us</a></li>
						<?php 
								//session_start();
								//if(isset($_SESSION['username']) && isset($_SESSION['password']))
								{
									?>
									 	<li><a href="carpool.php">Carpooling</a></li>
										<li><a href="couchsurfing.php">Couch_Surfing</a></li>
										<?php
								}
						?>
						
						<li><a href="carpool.php">Carpooling</a></li>
						<li><a href="couchsurfing.php">Couch_Surfing</a></li>
						<li><a href="gallery.php">Gallery</a></li>
						<li><a href="contact.php">Contact Us</a></li>
						<li><a href="login.php">login</a></li>-->
					</ul>
				</div><!-- /.navbar-collapse -->	
				
					</nav>
				</div>
				
				<div class="clearfix"> </div>
			</div>
			<!-- banner -->
			<!--Slider-->
					
			<div class="callbacks_container">
					<ul class="rslides" id="slider3">
						<li>
						
							<div class="slider-info">
							    <h3>#Free to <span>Disturb.</span> </h3>
							</div>
						</li>
						<li>
							<div class="slider-info">
							     <h3>#Connecting <span>peoples.</span> </h3>
						    </div>
						</li>
						<li>
							
							<div class="slider-info">
							     <h3>#Knock to pool <span>#Knock to surf.</span> </h3>
							</div>
						</li>
						

					</ul>
					
				<div class="clearfix"></div>
			</div>
			<!--//Slider-->
		</div>
		<div class="thim-click-to-bottom">
				<a href="#about" class="scroll">
					<i class="fa fa-long-arrow-down" aria-hidden="true"></i>
				</a>
			</div>
	</div>
<!-- //banner -->

<!-- Main -->


<!-- Services -->
<div class="services" id="services">
		<h3 class="title-w3">How it works</h3>
			<div class=" col-md-3 section-grid-wthree one">
				<div class="services-info-w3-agileits">
					<h5 class="sub-title">1. Going somewhere ?</h5>
					<p class="para-w3">Sometimes it's easier to meet people on your own,find people who travel on the same route and have same travel preference like you,travel together and give a rating after the ride</p>
				</div>
				<div class="services-img-agileits-w3layouts">
					<img src="images/ci.jpg" alt="service-img" width="" px height="200" px>
				</div>
			</div>
			<div class=" col-md-3 section-grid-wthree">
				<div class="services-img-agileits-w3layouts">
					<img src="images/Rediscover.png" width="208" px height="208" px alt="service-img">
				</div>
				<div class="services-info-w3-agileits mid">
					<h5 class="sub-title">2. Rediscover</h5>
					<p class="para-w3">There's a community of Knock users near you. Many cities have weekly language exchanges, dance classes, hikes and dinners,Knock out with them and make new friends.</p>
				</div>
			</div>
			<div class=" col-md-3 section-grid-wthree">
				<div class="services-info-w3-agileits">
					<h5 class="sub-title">3.Become a Host</h5>
					<p class="para-w3">Give back and open your home to travelers. Learn about a new culture & practice a language. Make the world a little smaller; a little friendlier; little more interesting.</p>
				</div>
				<div class="services-img-agileits-w3layouts">
					<img src="images/couch.jpg" alt="service-img" width="208" px height="208" px>
				</div>
			</div>
			<div class=" col-md-3 section-grid-wthree">
				<div class="services-img-agileits-w3layouts">
					<img src="images/travel.jpg" alt="service-img" height="210"px>
				</div>
				<div class="services-info-w3-agileits mid">
					<h5 class="sub-title">Travel the world</h5>
					<p class="para-w3">With Knock, you can stay with locals in every country in the world. Travel like a local, stay in someone's home and experience the world in a way money can't buy.</p>
				</div>
			</div>
		<div class="clearfix"></div>
</div>
<!-- //Services -->

<!-- Services -->
	<div class="why-choose-agile">
		<div class="container">
			<h3 class="w3l_head">Things you will love about Knock</h3>
			<div class="why-choose-agile-grids-top">
				<div class="col-md-4 agileits-w3layouts-grid">
					<div class="wthree_agile_us">
						<div class="col-xs-9 agile-why-text">
							<h4>You are in a control</h4>
							<p>Verified member profiles and ratings mean you know exactly who you're travelling with.</p>
						</div>
						<div class="col-xs-3 agile-why-text">
							<div class="wthree_features_grid hvr-rectangle-out">
								<i class="fa fa-check" aria-hidden="true"></i>
							</div>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="wthree_agile_us">
						<div class="col-xs-9 agile-why-text">
							<h4>Instant Chatting</h4>
							<p>Chat with your host,driver or any other knock user in just one click using chat option</p>
						</div>
						<div class="col-xs-3 agile-why-text">
							<div class="wthree_features_grid hvr-rectangle-out">
								<i class="fa fa-comments" aria-hidden="true"></i>
							</div>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="wthree_agile_us">
						<div class="col-xs-9 agile-why-text">
							<h4>Multiple Filter Options</h4>
							<p>Multiple filtering option are provided for faster and better search result by proving few answers</p>
						</div>
						<div class="col-xs-3 agile-why-text">
							<div class="wthree_features_grid hvr-rectangle-out">
								<i class="fa fa-sort-alpha-asc" aria-hidden="true"></i>
							</div>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
				<div class="col-md-4 agileits-w3layouts-grid img">
					<img src="images/services.png" alt=" " class="img-responsive" />
				</div>
				<div class="col-md-4 agileits-w3layouts-grid">
					<div class="wthree_agile_us">
					<div class="col-xs-3 agile-why-text">
							<div class="wthree_features_grid hvr-rectangle-out">
								<i class="fa fa-credit-card" aria-hidden="true"></i>
							</div>
						</div>
						<div class="col-xs-9 agile-why-text two">
							<h4>Knock us with confidence</h4>
							<p>Government ID verification adds another level of security to member profiles.</p>
						</div>
						
						<div class="clearfix"> </div>
					</div>
					<div class="wthree_agile_us">
					<div class="col-xs-3 agile-why-text">
							<div class="wthree_features_grid hvr-rectangle-out">
								<i class="fa  fa-map-marker" aria-hidden="true"></i>
							</div>
						</div>
						<div class="col-xs-9 agile-why-text two">
							<h4>Get going faster</h4>
							<p>No need to travel across town, catch a ride or host leaving near you.</p>
						</div>
						
						<div class="clearfix"> </div>
					</div>
					<div class="wthree_agile_us">
					<div class="col-xs-3 agile-why-text">
							<div class="wthree_features_grid hvr-rectangle-out">
								<i class="fa   fa-money" aria-hidden="true"></i>
							</div>
						</div>
						<div class="col-xs-9 agile-why-text two">
							<h4>Multiple Payment options</h4>
							<p>For the convinent of Knock users multiple payment options are provided such as PayPal,Paytm and cash.</p>
						</div>
						
						<div class="clearfix"> </div>
					</div>
						
						<div class="clearfix"> </div>
					</div>
			</div>
				<div class="clearfix"> </div>
		</div>
	</div>
<!-- //services -->


<!-- //Main -->

<!-- Footer -->
<?php
include('footer.php');
?>
<!-- Footer -->	


<!-- js-scripts -->						
		<!-- js -->
			<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
			<script type="text/javascript" src="js/bootstrap.js"></script> 
			<!-- Necessary-JavaScript-File-For-Bootstrap --> 
		<!-- //js -->
		
		<script src="js/responsiveslides.min.js"></script>
							<script>
								// You can also use "$(window).load(function() {"
								$(function () {
								  // Slideshow 4
								  $("#slider3").responsiveSlides({
									auto: true,
									pager:true,
									nav:false,
									speed: 500,
									namespace: "callbacks",
									before: function () {
									  $('.events').append("<li>before event fired.</li>");
									},
									after: function () {
									  $('.events').append("<li>after event fired.</li>");
									}
								  });
							
								});
							 </script>
		
							
								
		<!-- Starts-Number-Scroller-Animation-JavaScript -->
				<script type="text/javascript" src="js/numscroller-1.0.js"></script>
		<!-- //Starts-Number-Scroller-Animation-JavaScript -->
		
		
		
			<!-- particles-JavaScript -->
			<script src="js/particles.min.js"></script>
				<script>
				  window.onload = function() {
					Particles.init({
					  selector: '#myCanvas',
					  color: '#b3b3b3',
					  connectParticles: true,
					  minDistance: 100
					});
				  };
				</script>
	
		<!-- //particles-JavaScript -->
		
		<!-- team-plugin -->
			<script src="js/mislider.js" type="text/javascript"></script>
				<script type="text/javascript">
						jQuery(function ($) {
							var slider = $('.mis-stage').miSlider({
								//  The height of the stage in px. Options: false or positive integer. false = height is calculated using maximum slide heights. Default: false
								stageHeight: 380,
								//  Number of slides visible at one time. Options: false or positive integer. false = Fit as many as possible.  Default: 1
								slidesOnStage: false,
								//  The location of the current slide on the stage. Options: 'left', 'right', 'center'. Defualt: 'left'
								slidePosition: 'center',
								//  The slide to start on. Options: 'beg', 'mid', 'end' or slide number starting at 1 - '1','2','3', etc. Defualt: 'beg'
								slideStart: 'mid',
								//  The relative percentage scaling factor of the current slide - other slides are scaled down. Options: positive number 100 or higher. 100 = No scaling. Defualt: 100
								slideScaling: 150,
								//  The vertical offset of the slide center as a percentage of slide height. Options:  positive or negative number. Neg value = up. Pos value = down. 0 = No offset. Default: 0
								offsetV: -5,
								//  Center slide contents vertically - Boolean. Default: false
								centerV: true,
								//  Opacity of the prev and next button navigation when not transitioning. Options: Number between 0 and 1. 0 (transparent) - 1 (opaque). Default: .5
								navButtonsOpacity: 1,
							});
						});
					</script>
		<!-- //team-plugin -->

		<!-- start-smoth-scrolling -->
			<script type="text/javascript" src="js/move-top.js"></script>
			<script type="text/javascript" src="js/easing.js"></script>
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
						event.preventDefault();
						$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
					});
				});
			</script>
		<!-- start-smoth-scrolling -->


<!-- //js-scripts -->
</body>
</html>