<?php
	include('conn.php');

		if(isset($_GET['submit']))

			$name=$_GET['name'];
			$email=$_GET['email'];
			$phone=$_GET['phone'];
			$message=$_GET['message'];

			echo $name;
			echo $email;
			echo $phone;
			echo $message;

			$sql="insert into `contact` values ('','$name','$email',$phone,'$message')";


				$result=mysql_query($sql,$link);
				if($result)
				{
					echo"You are Registered...";
				}
				else
				{

					echo"Not";
				}
?>
