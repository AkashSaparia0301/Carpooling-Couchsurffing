
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->


<!DOCTYPE html>

<html lang="en">
<head>
<title>KNOCK</title>

<!-- Meta tag Keywords -->

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Auto Car Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>

<!--// Meta tag Keywords -->

<!-- css files -->

<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /> <!-- Bootstrap-Core-CSS -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /> <!-- Style-CSS --> 
<link rel="stylesheet" href="css/font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->

<!-- //css files -->

<!-- online-fonts -->

<link href="//fonts.googleapis.com/css?family=Jockey+One&amp;subset=latin-ext" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Niconne&amp;subset=latin-ext" rel="stylesheet">

<!-- //online-fonts -->
<style> 
/*input[type=text] 
{
  	width: 130px;
    box-sizing: border-box;
	border:  solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    
	background-color: transparent;
	
    background-image: url();
	 
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}

input[type=text]:focus 
{
    width: 100%;
}*/
</style>
</head>
	
<body>
<!-- banner -->
	<div class="banner-3 wthree">
		<div class="container">
			<div class="banner_top">
		        <!--<form>	 
				<input type="text" name="search" placeholder="Search..">
		        </form>-->
				<div class="logo wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
					<h1><a href="index.html"><span>K</span>nock</a></h1>
				</div>
				<div class="banner_top_right wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
					<nav class="navbar navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div cla1ss="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav cl-effect-14">
					<?php
					include('process.php');
					?>
						<!--<li><a href="index.php">Home</a></li>
						<li><a href="about.php">About Us</a></li>
						<?php 
								//session_start();
								//if(isset($_SESSION['username']) && isset($_SESSION['password']))
								{
									?>
									 	<li><a href="carpool.php">Carpooling</a></li>
										<li><a href="couchsurfing.php">Couch_Surfing</a></li>
										<?php
								}
						?>
						
						<li><a href="carpool.php">Carpooling</a></li>
						<li><a href="couchsurfing.php">Couch_Surfing</a></li>
						<li><a href="services.html">Services</a></li>
						<li><a href="gallery.php" class="active">Gallery</a></li>
						<li><a href="codes.html">Codes</a></li>
						<li><a href="contact.php">Contact Us</a></li>
						<li><a href="login.php">Login</a></li>-->
					</ul>
				</div><!-- /.navbar-collapse -->	
				
			</nav>
				</div>
				<div class="clearfix"> </div>
			</div>
			<!-- banner -->
		
		</div>
	</div>
<!-- //banner -->

<!-- Main -->
<!-- Gallery -->
	<div class="gallery">
		<div class="container">
			<h2>Gallery</h2>
			<div class="wthree_gallery_grids">
				<div id="jzBox" class="jzBox">
					<div id="jzBoxNextBig"></div>
					<div id="jzBoxPrevBig"></div>
					<img src="#" id="jzBoxTargetImg" alt=" " />
					<div id="jzBoxBottom">
						<div id="jzBoxTitle"></div>
						<div id="jzBoxMoreItems">
							<div id="jzBoxCounter"></div>
							<i class="arrow-left" id="jzBoxPrev"></i> 
							<i class="arrow-right" id="jzBoxNext"></i> 
						</div>
						<i class="close" id="jzBoxClose"></i>
					</div>
				</div>
                <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
					<div id="myTabContent" class="tab-content">
						<div role="tabpanel" class="tab-pane fade in active" id="hom111e">
							<div class="tab_img">
								<div class="col-md-3 agile_gallery_grids">
									<a href="images/g1.jpg" class="jzBoxLink" title="Knock">
										<div class="view view-sixth">
											<img src="images/g1.jpg" alt=" " class="img-responsive"  />
											<div class="mask">
												<p> City to City carpooling...</p>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-3 agile_gallery_grids">
									<a href="images/g4.jpg" class="jzBoxLink" title="Knock">
										<div class="view view-sixth">
											<img src="images/g4.jpg" alt=" " class="img-responsive" height="508"px/>
											<div class="mask">
												<p>Let's pack your car Smartly-Because knock journeys are all about comfort..!</p>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-3 agile_gallery_grids">
									<a href="images/g2.jpg"  class="jzBoxLink" title="Knock">
										<div class="view view-sixth">
											<img src="images/g2.jpg"   alt=" " class="img-responsive" />
											<div class="mask">
												<p>Be Social..!</p>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-3 agile_gallery_grids">
									<a href="images/g5.jpg" class="jzBoxLink" title="Knock">
										<div class="view view-sixth">
											<img src="images/g5.jpg" alt=" " class="img-responsive" />
											<div class="mask">
												<p>#knock Camps :)</p>
											</div>
										</div>
									</a>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="tab_img">
								<div class="col-md-3 agile_gallery_grids">
									<a href="images/g6.jpg" class="jzBoxLink" title="Knock">
										<div class="view view-sixth">
											<img src="images/g6.jpg" alt=" " class="img-responsive" />
											<div class="mask">
												<p>#knock night outs :)</p>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-3 agile_gallery_grids">
									<a href="images/NewYear.png" class="jzBoxLink" title="knock">
										<div class="view view-sixth">
											<img src="images/NewYear.png" alt=" " class="img-responsive" />
											<div class="mask">
												<p>#NewYear Party</p>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-3 agile_gallery_grids">
									<a href="images/christmas.jpg" class="jzBoxLink" title="knock">
										<div class="view view-sixth">
											<img src="images/christmas.jpg" alt=" " class="img-responsive" />
											<div class="mask">
												<p>#Our Christmas Party</p>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-3 agile_gallery_grids">
									<a href="images/enjoy1.jpg" class="jzBoxLink" title="knock">
										<div class="view view-sixth">
											<img src="images/enjoy1.jpg" alt=" " class="img-responsive" />
											<div class="mask">
												<p>A shared trip is better trip</p>
											</div>
										</div>
									</a>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="tab_img">
								<div class="col-md-3 agile_gallery_grids">
									<a href="images/meet.jpg" class="jzBoxLink" title="knock">
										<div class="view view-sixth">
											<img src="images/meet.jpg" alt=" " class="img-responsive" />
											<div class="mask">
												<p>Meet new people on knock and increase your friend list..!</p>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-3 agile_gallery_grids">
									<a href="images/tttt.jpg" class="jzBoxLink" title="knock">
										<div class="view view-sixth">
											<img src="images/tttt.jpg" alt=" " class="img-responsive" />
											<div class="mask">
												<p> @TomorrowLand,Belgium </p>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-3 agile_gallery_grids">
									<a href="images/friend.jpg" class="jzBoxLink" title="knock">
										<div class="view view-sixth">
											<img src="images/friend.jpg" alt=" " class="img-responsive" />
											<div class="mask">
												<p>#Friendship Day Celebration :)</p>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-3 agile_gallery_grids">
									<a href="images/download.jpg" class="jzBoxLink" title="Knock">
										<div class="view view-sixth">
											<img src="images/download.jpg" alt=" " class="img-responsive" />
											<div class="mask">
												<p>Earth Day Celebration By Knock users</p>
											</div>
										</div>
									</a>
								</div>
								<div class="clearfix"> </div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<!-- //Gallery -->
<!-- //Main -->

<!-- Footer -->

<?php
include('footer.php');
?>

<!-- Footer -->	

<!-- js-scripts -->						
		<!-- js -->
			<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
			<script type="text/javascript" src="js/bootstrap.js"></script> <!-- Necessary-JavaScript-File-For-Bootstrap --> 
		<!-- //js -->
		<script src="js/jzBox.js"></script>
<!-- //js-scripts -->
</body>
</html>