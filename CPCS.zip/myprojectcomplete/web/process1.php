<?php
if(isset($_SESSION['username']) && isset($_SESSION['password']))
{
	?>

						<li><a href="index.php ">Home</a></li>
						<li><a href="about.php">About Us</a></li>
					
								
									 	<li><a href="carpool.php">Carpooling</a></li>
										<li><a href="couchsurfing.php">Couch_Surfing</a></li>
										<!--<li><a href="index.php">Log-Out</a></li>-->
										
							     		
					
						<!--<li><a href="services.html">Services</a></li>-->
						<li><a href="gallery.php">Gallery</a></li>
						<!--<li><a href="codes.html">Codes</a></li>-->
						<li><a href="contact.php">Contact Us</a></li>
						<li><a href="logout.php">log-out</a></li>
					
					<?php
}	
else	
{
	?>

	<li><a href="index.php">Home</a></li>
						<li><a href="about.php" >About Us</a></li>
						<li><a href="gallery.php">Gallery</a></li>
						<li><a href="contact.php">Contact Us</a></li>
						<li><a href="login.php">log-in</a></li>
					
						
<?php
}	
?>
