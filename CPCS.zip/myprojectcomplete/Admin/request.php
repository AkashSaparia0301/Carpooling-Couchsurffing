<?php
SESSION_START();
$l=$_POST['leavingfrom'];
echo $l;
$g=$_POST['goingto'];
echo $g;
$c=$_POST['createdon'];
echo $c;

$query1="select * from new_offer_ride";
$result1=mysql_query($query1,$conn);
while($row=mysql_fetch_array($result1))
{
	echo $row[8];
	echo $row[9];
}


?>

<?php/*
	$conn=mysql_connect("localhost","root","");
	mysql_select_db("cscp",$conn);
	$result=mysql_query("select * from `new_offer_ride` where pickup_address='$l' && destination_address='$g'");
*/?>
<html>
<head>
<title>REQUEST</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Augment Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
	<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
	<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
	<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'>
	<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
	<!-- /js -->
<script src="js/jquery-1.10.2.min.js"></script>
<!-- //js-->
</head> 
<body>
<h3 class="inner-tittle two"style="font-align:center">REQUEST </h3>
	<div class="graph">
			<div class="tables">
					<table class="table"> 
					
					<thead> 
					<tr> 
					<th>offer_id</th>
						<th>name</th>
						<th>e_mail</th>
						<th>contact_number</th>
						<th>departure_date</th>
						<th>departure_time</th>
						<th>return_date</th>
						<th>return_time</th>
						<th>pickup_address</th>
						<th>destination_address</th>
						<th>journey</th>
						<th>per_person_cost</th> 
						<th>book-ride</th>
					</tr> 
					</thead> 
	<?php/*
	while($row=mysql_fetch_array($result))
	{
		echo"<tr>";
		echo"<th>".$row[0]."</th>";
		echo"<th>".$row[1]."</th>";
		echo"<th>".$row[2]."</th>";
		echo"<th>".$row[3]."</th>";
		echo"<th>".$row[4]."</th>";
		echo"<th>".$row[5]."</th>";
		echo"<th>".$row[6]."</th>";
		echo"<th>".$row[7]."</th>";
		echo"<th>".$row[8]."</th>";
		echo"<th>".$row[9]."</th>";
		echo"<th>".$row[10]."</th>";
		echo"<th>".$row[11]."</th>";
		echo"</tr>";
	}*/
?>	
					
					</table> 
			</div>
					
	</div>
	
	
	
	
	
	
	
	
	
	
	
</body>
</html>