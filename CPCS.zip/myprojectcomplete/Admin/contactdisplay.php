<?php
	$conn=mysql_connect("localhost","root","");
	mysql_select_db("carpooling_couchsurfing",$conn);
	$result=mysql_query("SELECT * FROM contact");

	/*if(isset($_GET['cp_preference_id']))
	{

	$id=$_GET['cp_preference_id'];
	
	//$query2="DELETE FROM new_member where member_id='$id'";
	$query2="DELETE FROM `cscp`.`new_cp_member_preference` WHERE `new_cp_member_preference`.`cp_preference_id` ='$id'";
	$result1=mysql_query($query2);
	}*/
					
?>
<html>
<head>
<title>cp_preference_table</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Augment Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
	<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
	<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
	<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'>
	<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
	<!-- /js -->
<script src="js/jquery-1.10.2.min.js"></script>
<!-- //js-->
</head> 
<body>
<h3 class="inner-tittle two"style="font-align:center">Contact Table </h3>
	<div class="graph">
			<div class="tables">
					<table class="table"> 
					
					<thead> 
					<tr> 
							<th>C_id</th>
							<th>Name</th>
							<th>Email</th>
							<th>Phone</th>
							<th>Message</th>
							<th>Delete</th>
							
							
					</tr> 
					</thead> 
	
	<?php
	while($row=mysql_fetch_row($result))
	{
	
		echo"<tr>";
		//echo '<th><a href="memberdisplay.php?member_id='.$row['member_id'].'">Delete</a></th>';
		
		echo"<th>".$row[0]."</th>";
		echo"<th>".$row[1]."</th>";
		echo"<th>".$row[2]."</th>";
		echo"<th>".$row[3]."</th>";
		echo"<th>".$row[4]."</th>";
		
		
	
		
		?>
		<th><a href="cp_preference_display.php?cp_preference_id=<?php echo $row[0];?>" >DELETE</a></th>
	<?php
		echo"</tr>";
	}	
	?>
	
					<!--<tbody> 
					<tr class="active"> 
					<th scope="row">1</th> 
					<td>Column content</td> 
					<td>Column content</td> 
					<td>Column content</td> 
					</tr> 
					<tr> 
					<th scope="row">2</th> 
					<td>Column content</td> 
					<td>Column content</td> 
					<td>Column content</td> 
					</tr> 
					<tr class="success"> 
					<th scope="row">3</th> 
					<td>Column content</td> 
					<td>Column content</td> 
					<td>Column content</td> 
					</tr> 
					<tr> 
					<th scope="row">4</th> 
					<td>Column content</td> 
					<td>Column content</td> 
					<td>Column content</td> 
					</tr> <tr class="info"> 
					<th scope="row">5</th> 
					<td>Column content</td> 
					<td>Column content</td> 
					<td>Column content</td> 
					</tr> 
					<tr> 
					<th scope="row">6</th> 
					<td>Column content</td> 
					<td>Column content</td> 
					<td>Column content</td> 
					</tr> <tr class="warning"> 
					<th scope="row">7</th> 
					<td>Column content</td> 
					<td>Column content</td> 
					<td>Column content</td> 
					</tr> 
					<tr> <th scope="row">8</th> 
					<td>Column content</td> 
					<td>Column content</td> 
					<td>Column content</td> 
					</tr> 
					<tr class="danger"> 
					<th scope="row">9</th> 
					<td>Column content</td> 
					<td>Column content</td> 
					<td>Column content</td> 
					</tr> 
					</tbody> -->
					</table> 
			</div>
					
	</div>
</body>
</html>