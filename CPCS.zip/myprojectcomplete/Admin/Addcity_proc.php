<?php

$conn=mysql_connect("localhost","root","");
	mysql_select_db("carpooling_couchsurfing",$conn);
if(isset($_POST['city']))
{

$city_name=$_POST['city_name'];
$state=$_POST['state'];
$country=$_POST['country'];
}

$sql = "insert into city(city_name,state,country)values('$city_name','$state','$country')";
//$sql1 = "insert into city(state)values('$state')";
//$sql2 = "insert into city(country)values('$country')";

$result=mysql_query($sql,$conn);
//$result=mysql_query($sql1,$conn);
//$result=mysql_query($sql2,$conn);
if ($result==TRUE)
	header("location:citydisplay.php");

?>
