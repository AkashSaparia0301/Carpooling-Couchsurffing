<form action="kuch.php" method="POST">
Car_id
<input type="text" name="car_id">
<!--Member_id
<input type="text" name="member_id">-->
Car_name
<input type="text" name="Car_name">
Model
<input type="text" name="model">
Make_year
<input type="text" name="make_year">
Number_plate
<input type="text" name="number_plate">
Type_of_car
<input type="text" name="type_of_car">
color
<input type="text" name="color">
Number_of_seats
<input type="text" name="no_of_seats_offered">
<input type="submit" name="submit" value="submit">
</form>


<?php
	$link=mysql_connect("localhost","root","");
	mysql_select_db("carpooling_couchsurfing",$link);
	
	if($link)
	{
		echo "succesful";
	}
	
	if(isset($_POST['submit']))
	{
		$car_id =  $_POST['car_id'];
		/*$member_id = $_POST['member_id'];**/
		$Car_name = $_POST['Car_name'];
		$model = $_POST['model'];
		$make_year = $_POST['make_year'];
		$number_plate = $_POST['number_plate'];
		$type_of_car = $_POST['type_of_car'];
		$color = $_POST['color'];
		$no_of_seats_offered = $_POST['no_of_seats_offered'];
		
		/*$sql=mysql_query($sql,$link);*/
		
		$sql = "INSERT INTO `car` (`car_id`, `Car_name`, `model`, `make_year`, `number_plate`, `type_of_car`, `color`, `no_of_seats_offered`) VALUES ($car_id,'$Car_name','$model', $make_year, $number_plate, '$type_of_car', '$color', $no_of_seats_offered);";
		
		
		
	 echo "<h4>You Are Registered..  </h4>";
	}
	$query="select * from car";
	$result=mysql_query($query,$link);
?>